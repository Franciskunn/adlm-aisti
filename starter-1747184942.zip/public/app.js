// Global state
let currentUser = null;
let students = [];
let selectedGradeLevel = 7;
let selectedStudents = [];

// DOM Elements
const app = document.getElementById("app");

// Initialize the application
function initApp() {
  // Check if user is logged in
  const userStr = localStorage.getItem("currentUser");
  if (userStr) {
    currentUser = JSON.parse(userStr);
    if (currentUser.role === "admin") {
      renderAdminDashboard();
    } else {
      renderStudentPortal();
    }
  } else {
    renderAuth();
  }

  // Initialize admin account if it doesn't exist
  initializeAdminAccount();

  // Initialize sample students if they don't exist
  initializeSampleStudents();
}

// Initialize admin account
function initializeAdminAccount() {
  const users = JSON.parse(localStorage.getItem("users") || "[]");

  // Check if admin account exists
  const adminExists = users.some((user) => user.role === "admin");

  if (!adminExists) {
    // Create admin account
    const adminUser = {
      username: "DepedAmba",
      password: "Ambalayat@123",
      role: "admin",
    };

    localStorage.setItem("users", JSON.stringify([...users, adminUser]));
  }
}

// Initialize sample students
function initializeSampleStudents() {
  const storedStudents = localStorage.getItem("students");
  if (!storedStudents) {
    const sampleStudents = generateSampleStudents();
    localStorage.setItem("students", JSON.stringify(sampleStudents));
    students = sampleStudents;
  } else {
    students = JSON.parse(storedStudents);
  }
}

// Generate sample student data
function generateSampleStudents() {
  const gradeLevels = [7, 8, 9, 10];
  const sampleStudents = [
    {
      id: "1",
      name: "John Doe",
      parentEmail: "parent1@example.com",
      q1: 92,
      q2: 88,
      q3: 90,
      q4: 94,
      average: 91,
      gradeLevel: 7,
    },
    {
      id: "2",
      name: "Jane Smith",
      parentEmail: "parent2@example.com",
      q1: 85,
      q2: 82,
      q3: 88,
      q4: 90,
      average: 86.25,
      gradeLevel: 8,
    },
    {
      id: "3",
      name: "Michael Johnson",
      parentEmail: "parent3@example.com",
      q1: 78,
      q2: 80,
      q3: 75,
      q4: 82,
      average: 78.75,
      gradeLevel: 9,
    },
    {
      id: "4",
      name: "Emily Williams",
      parentEmail: "parent4@example.com",
      q1: 95,
      q2: 92,
      q3: 97,
      q4: 94,
      average: 94.5,
      gradeLevel: 10,
    },
    {
      id: "5",
      name: "David Brown",
      parentEmail: "parent5@example.com",
      q1: 70,
      q2: 68,
      q3: 72,
      q4: 74,
      average: 71,
      gradeLevel: 7,
    },
  ];

  // Add more random students
  const names = [
    "Alex",
    "Taylor",
    "Jordan",
    "Casey",
    "Riley",
    "Morgan",
    "Avery",
    "Quinn",
  ];
  const lastNames = [
    "Garcia",
    "Rodriguez",
    "Lee",
    "Wong",
    "Kim",
    "Patel",
    "Singh",
    "Nguyen",
  ];

  for (let i = 6; i <= 40; i++) {
    const firstName = names[Math.floor(Math.random() * names.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const gradeLevel =
      gradeLevels[Math.floor(Math.random() * gradeLevels.length)];

    const q1 = Math.floor(Math.random() * 31) + 70; // 70-100
    const q2 = Math.floor(Math.random() * 31) + 70;
    const q3 = Math.floor(Math.random() * 31) + 70;
    const q4 = Math.floor(Math.random() * 31) + 70;
    const average = parseFloat(((q1 + q2 + q3 + q4) / 4).toFixed(2));

    sampleStudents.push({
      id: i.toString(),
      name: `${firstName} ${lastName}`,
      parentEmail: `parent${i}@example.com`,
      q1,
      q2,
      q3,
      q4,
      average,
      gradeLevel,
    });
  }

  return sampleStudents;
}

// Render authentication page
function renderAuth() {
  app.innerHTML = `
    <div class="auth-container">
      <div class="auth-card">
        <div class="auth-header">
          <h2 class="auth-title">ALDM Grade Tracking System</h2>
          <p class="auth-description">Enter your credentials to access your account</p>
        </div>
        <div class="auth-content">
          <div class="tabs">
            <div class="tab active" data-tab="login">Login</div>
            <div class="tab" data-tab="register">Register</div>
          </div>
          
          <div class="tab-content active" id="login-tab">
            <form id="login-form" class="space-y-4">
              <div class="form-group">
                <label class="form-label" for="username">Username</label>
                <div class="form-input-wrapper">
                  <span class="form-icon">👤</span>
                  <input class="form-input" id="username" name="username" placeholder="Enter your username" />
                </div>
              </div>
              
              <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <div class="form-input-wrapper">
                  <span class="form-icon">🔒</span>
                  <input class="form-input" id="password" name="password" type="password" placeholder="Enter your password" />
                </div>
              </div>
              
              <div id="login-error" class="error-message" style="display: none;"></div>
              
              <button type="submit" class="form-button">Sign In</button>
            </form>
          </div>
          
          <div class="tab-content" id="register-tab">
            <form id="register-form" class="space-y-4">
              <div class="form-group">
                <label class="form-label" for="reg-username">Username</label>
                <div class="form-input-wrapper">
                  <span class="form-icon">👤</span>
                  <input class="form-input" id="reg-username" name="username" placeholder="Choose a username" />
                </div>
              </div>
              
              <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <div class="form-input-wrapper">
                  <span class="form-icon">✉️</span>
                  <input class="form-input" id="email" name="email" type="email" placeholder="Enter your email" />
                </div>
              </div>
              
              <div class="form-group">
                <label class="form-label" for="reg-password">Password</label>
                <div class="form-input-wrapper">
                  <span class="form-icon">🔒</span>
                  <input class="form-input" id="reg-password" name="password" type="password" placeholder="Create a password" />
                </div>
              </div>
              
              <div class="form-group">
                <label class="form-label" for="confirm-password">Confirm Password</label>
                <div class="form-input-wrapper">
                  <span class="form-icon">🔒</span>
                  <input class="form-input" id="confirm-password" name="confirmPassword" type="password" placeholder="Confirm your password" />
                </div>
              </div>
              
              <div id="register-error" class="error-message" style="display: none;"></div>
              <div id="register-success" class="success-message" style="display: none;"></div>
              
              <button type="submit" class="form-button">Create Account</button>
            </form>
          </div>
        </div>
        <div class="auth-footer">
          <p>By continuing, you agree to our Terms of Service and Privacy Policy.</p>
          <p>© 2023 ALDM Grade Tracking System. All rights reserved.</p>
        </div>
      </div>
    </div>
  `;

  // Add event listeners
  const tabs = document.querySelectorAll(".tab");
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const tabName = tab.getAttribute("data-tab");

      // Update active tab
      document
        .querySelectorAll(".tab")
        .forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");

      // Show active content
      document
        .querySelectorAll(".tab-content")
        .forEach((content) => content.classList.remove("active"));
      document.getElementById(`${tabName}-tab`).classList.add("active");
    });
  });

  // Login form submission
  const loginForm = document.getElementById("login-form");
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Validate inputs
    if (!username || !password) {
      showError("login-error", "Please fill in all fields");
      return;
    }

    // Check credentials
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const user = users.find(
      (u) => u.username === username && u.password === password,
    );

    if (user) {
      // Set current user in localStorage
      localStorage.setItem(
        "currentUser",
        JSON.stringify({
          username: user.username,
          role: user.role,
        }),
      );

      currentUser = {
        username: user.username,
        role: user.role,
      };

      // Redirect based on role
      if (user.role === "admin") {
        renderAdminDashboard();
      } else {
        renderStudentPortal();
      }
    } else {
      showError("login-error", "Invalid username or password");
    }
  });

  // Register form submission
  const registerForm = document.getElementById("register-form");
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("reg-username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("reg-password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    // Validate form
    if (!username || !email || !password || !confirmPassword) {
      showError("register-error", "Please fill in all fields");
      return;
    }

    if (password !== confirmPassword) {
      showError("register-error", "Passwords do not match");
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      showError("register-error", "Please enter a valid email address");
      return;
    }

    // Get existing users
    const users = JSON.parse(localStorage.getItem("users") || "[]");

    // Check if username already exists
    if (users.some((user) => user.username === username)) {
      showError("register-error", "Username already exists");
      return;
    }

    // Create new user
    const newUser = {
      username,
      email,
      password,
      role: "student",
    };

    // Save to localStorage
    localStorage.setItem("users", JSON.stringify([...users, newUser]));

    // Show success message and reset form
    document.getElementById("register-error").style.display = "none";
    document.getElementById("register-success").textContent =
      "Registration successful! You can now log in.";
    document.getElementById("register-success").style.display = "block";
    registerForm.reset();

    // Switch to login tab after 2 seconds
    setTimeout(() => {
      document.querySelector('.tab[data-tab="login"]').click();
      document.getElementById("register-success").style.display = "none";
    }, 2000);
  });
}

// Render admin dashboard
function renderAdminDashboard() {
  // Load students from localStorage
  students = JSON.parse(localStorage.getItem("students") || "[]");

  app.innerHTML = `
    <div class="dashboard">
      <div class="dashboard-header">
        <div>
          <h1 class="dashboard-title">ALDM Admin Dashboard</h1>
          <p class="dashboard-subtitle">Welcome back, ${currentUser.username}</p>
        </div>
        <button id="logout-button" class="logout-button">
          <span>🚪</span> Logout
        </button>
      </div>
      
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-header">
            <h3 class="stat-title">Total Students</h3>
            <p class="stat-description">Across all grade levels</p>
          </div>
          <div class="stat-content">
            <span class="stat-icon">👥</span>
            <span class="stat-value">${students.length}</span>
          </div>
        </div>
        
        <div class="stat-card">
          <div class="stat-header">
            <h3 class="stat-title">Grade Reports</h3>
            <p class="stat-description">Generated this quarter</p>
          </div>
          <div class="stat-content">
            <span class="stat-icon">📄</span>
            <span class="stat-value">24</span>
          </div>
        </div>
        
        <div class="stat-card">
          <div class="stat-header">
            <h3 class="stat-title">Messages Sent</h3>
            <p class="stat-description">To parents this month</p>
          </div>
          <div class="stat-content">
            <span class="stat-icon">✉️</span>
            <span class="stat-value">18</span>
          </div>
        </div>
      </div>
      
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Student Records</h2>
          <p class="card-description">Manage student data, grades, and communications</p>
        </div>
        <div class="card-content">
          <div class="tabs-list">
            <div class="tab-trigger active" data-tab="all-students">All Students</div>
            <div class="tab-trigger" data-tab="grade-levels">Grade Levels</div>
            <div class="tab-trigger" data-tab="reports">Reports</div>
          </div>
          
          <div class="tab-content active" id="all-students-tab">
            <div class="search-container">
              <input id="student-search" class="search-input" placeholder="Search students by name or email..." />
              <span class="search-icon">🔍</span>
            </div>
            
            <div class="select-container" style="margin-bottom: 1rem;">
              <select id="grade-level-select" class="select">
                <option value="all">All Grades</option>
                <option value="7">Grade 7</option>
                <option value="8">Grade 8</option>
                <option value="9">Grade 9</option>
                <option value="10">Grade 10</option>
              </select>
              <span class="select-icon">▼</span>
            </div>
            
            <div class="table-container">
              <table class="table" id="students-table">
                <thead class="table-header">
                  <tr>
                    <th>
                      <input type="checkbox" class="checkbox" id="select-all-students" />
                    </th>
                    <th>Student Name</th>
                    <th>Parent Email</th>
                    <th>Q1</th>
                    <th>Q2</th>
                    <th>Q3</th>
                    <th>Q4</th>
                    <th>Average</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody id="students-table-body">
                  <!-- Student rows will be inserted here -->
                </tbody>
              </table>
            </div>
          </div>
          
          <div class="tab-content" id="grade-levels-tab">
            <div class="tabs-list">
              <div class="tab-trigger active" data-tab="grade-7">Grade 7</div>
              <div class="tab-trigger" data-tab="grade-8">Grade 8</div>
              <div class="tab-trigger" data-tab="grade-9">Grade 9</div>
              <div class="tab-trigger" data-tab="grade-10">Grade 10</div>
            </div>
            
            <div id="grade-level-content">
              <!-- Grade level content will be inserted here -->
            </div>
          </div>
          
          <div class="tab-content" id="reports-tab">
            <div class="stats-grid">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Individual Reports</h3>
                </div>
                <div class="card-content">
                  <p style="color: #aaaaaa; margin-bottom: 1rem;">Generate detailed reports for individual students</p>
                  <button class="form-button">Generate Individual Report</button>
                </div>
              </div>
              
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Class Reports</h3>
                </div>
                <div class="card-content">
                  <p style="color: #aaaaaa; margin-bottom: 1rem;">Generate reports for entire grade levels</p>
                  <button class="form-button">Generate Class Report</button>
                </div>
              </div>
              
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Scheduled Reports</h3>
                </div>
                <div class="card-content">
                  <p style="color: #aaaaaa; margin-bottom: 1rem;">Set up automated quarterly reports</p>
                  <button class="form-button">Schedule Reports</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  // Add event listeners
  document
    .getElementById("logout-button")
    .addEventListener("click", handleLogout);

  // Tab switching
  const tabTriggers = document.querySelectorAll(".tab-trigger");
  tabTriggers.forEach((trigger) => {
    trigger.addEventListener("click", () => {
      const tabName = trigger.getAttribute("data-tab");

      // Find the parent tabs-list
      const tabsList = trigger.closest(".tabs-list");

      // Update active trigger in this list
      tabsList
        .querySelectorAll(".tab-trigger")
        .forEach((t) => t.classList.remove("active"));
      trigger.classList.add("active");

      // If this is the main tab list
      if (
        tabName === "all-students" ||
        tabName === "grade-levels" ||
        tabName === "reports"
      ) {
        document
          .querySelectorAll(".card-content > .tab-content")
          .forEach((content) => content.classList.remove("active"));
        document.getElementById(`${tabName}-tab`).classList.add("active");
      } else if (tabName.startsWith("grade-")) {
        // Handle grade level tabs
        const gradeNumber = tabName.split("-")[1];
        renderGradeLevelContent(parseInt(gradeNumber));
      }
    });
  });

  // Search and filter functionality
  const searchInput = document.getElementById("student-search");
  const gradeLevelSelect = document.getElementById("grade-level-select");

  searchInput.addEventListener("input", () => {
    renderStudentTable();
  });

  gradeLevelSelect.addEventListener("change", () => {
    renderStudentTable();
  });

  // Select all checkbox
  const selectAllCheckbox = document.getElementById("select-all-students");
  selectAllCheckbox.addEventListener("change", () => {
    const isChecked = selectAllCheckbox.checked;
    selectedStudents = isChecked
      ? getFilteredStudents().map((student) => student.id)
      : [];
    renderStudentTable();
  });

  // Initial render of student table
  renderStudentTable();

  // Initial render of grade level content
  renderGradeLevelContent(7);
}

// Render student table
function renderStudentTable() {
  const tableBody = document.getElementById("students-table-body");
  const filteredStudents = getFilteredStudents();

  // Check if select all should be checked
  const selectAllCheckbox = document.getElementById("select-all-students");
  selectAllCheckbox.checked =
    filteredStudents.length > 0 &&
    filteredStudents.every((student) => selectedStudents.includes(student.id));

  if (filteredStudents.length === 0) {
    tableBody.innerHTML = `
      <tr class="table-row">
        <td class="table-cell" colspan="9" style="text-align: center;">No students found.</td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = filteredStudents
    .map((student) => {
      const isSelected = selectedStudents.includes(student.id);

      return `
      <tr class="table-row">
        <td class="table-cell">
          <input type="checkbox" class="checkbox student-checkbox" 
            data-student-id="${student.id}" ${isSelected ? "checked" : ""} />
        </td>
        <td class="table-cell">${student.name}</td>
        <td class="table-cell">${student.parentEmail}</td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.q1)}">${student.q1}</span>
        </td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.q2)}">${student.q2}</span>
        </td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.q3)}">${student.q3}</span>
        </td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.q4)}">${student.q4}</span>
        </td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.average)}">${student.average.toFixed(1)}</span>
        </td>
        <td class="table-cell">
          <div class="action-buttons">
            <button class="action-button action-button-blue view-student" data-student-id="${student.id}">
              👁️
            </button>
            <button class="action-button action-button-amber edit-student" data-student-id="${student.id}">
              ✏️
            </button>
            <button class="action-button action-button-red delete-student" data-student-id="${student.id}">
              🗑️
            </button>
          </div>
        </td>
      </tr>
    `;
    })
    .join("");

  // Add event listeners to checkboxes
  document.querySelectorAll(".student-checkbox").forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
      const studentId = checkbox.getAttribute("data-student-id");
      if (checkbox.checked) {
        if (!selectedStudents.includes(studentId)) {
          selectedStudents.push(studentId);
        }
      } else {
        selectedStudents = selectedStudents.filter((id) => id !== studentId);
      }

      // Update select all checkbox
      const selectAllCheckbox = document.getElementById("select-all-students");
      selectAllCheckbox.checked =
        filteredStudents.length > 0 &&
        filteredStudents.every((student) =>
          selectedStudents.includes(student.id),
        );
    });
  });

  // Add event listeners to action buttons
  document.querySelectorAll(".view-student").forEach((button) => {
    button.addEventListener("click", () => {
      const studentId = button.getAttribute("data-student-id");
      const student = students.find((s) => s.id === studentId);
      alert(`View student: ${student.name}`);
    });
  });

  document.querySelectorAll(".edit-student").forEach((button) => {
    button.addEventListener("click", () => {
      const studentId = button.getAttribute("data-student-id");
      const student = students.find((s) => s.id === studentId);
      handleEditStudent(student);
    });
  });

  document.querySelectorAll(".delete-student").forEach((button) => {
    button.addEventListener("click", () => {
      const studentId = button.getAttribute("data-student-id");
      handleDeleteStudent(studentId);
    });
  });
}

// Get filtered students based on search and grade level
function getFilteredStudents() {
  const searchTerm = document
    .getElementById("student-search")
    .value.toLowerCase();
  const selectedGradeLevel =
    document.getElementById("grade-level-select").value;

  return students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm) ||
      student.parentEmail.toLowerCase().includes(searchTerm);

    const matchesGradeLevel =
      selectedGradeLevel === "all" ||
      student.gradeLevel.toString() === selectedGradeLevel;

    return matchesSearch && matchesGradeLevel;
  });
}

// Get grade status class based on grade value
function getGradeStatusClass(grade) {
  if (grade >= 90) return "badge-green";
  if (grade >= 75) return "badge-blue";
  return "badge-red";
}

// Render grade level content
function renderGradeLevelContent(gradeLevel) {
  selectedGradeLevel = gradeLevel;
  const gradeStudents = students.filter(
    (student) => student.gradeLevel === gradeLevel,
  );

  // Calculate statistics
  const stats = calculateGradeLevelStats(gradeStudents);

  const contentContainer = document.getElementById("grade-level-content");
  contentContainer.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-header">
          <h3 class="stat-title">Total Students</h3>
        </div>
        <div class="stat-content">
          <span class="stat-value">${stats.count}</span>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-header">
          <h3 class="stat-title">Average Score</h3>
        </div>
        <div class="stat-content">
          <span class="stat-value">${stats.avgScore}</span>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-header">
          <h3 class="stat-title">Passing</h3>
        </div>
        <div class="stat-content">
          <span class="stat-value" style="color: #00cc00;">${stats.passing}</span>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-header">
          <h3 class="stat-title">Failing</h3>
        </div>
        <div class="stat-content">
          <span class="stat-value" style="color: #ff3333;">${stats.failing}</span>
        </div>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <h2 class="card-title">Grade ${gradeLevel} Student Records</h2>
        <p class="card-description">Spreadsheet view of all student grades and performance</p>
      </div>
      <div class="card-content">
        <div class="search-container">
          <input id="grade-student-search" class="search-input" placeholder="Search students by name or email..." />
          <span class="search-icon">🔍</span>
        </div>
        
        <div class="table-container">
          <table class="table">
            <thead class="table-header">
              <tr>
                <th>
                  <input type="checkbox" class="checkbox" id="grade-select-all" />
                </th>
                <th>Student Name</th>
                <th>Parent Email</th>
                <th>Q1</th>
                <th>Q2</th>
                <th>Q3</th>
                <th>Q4</th>
                <th>Average</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="grade-students-table-body">
              ${renderGradeStudentsRows(gradeStudents)}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;

  // Add event listeners
  const searchInput = document.getElementById("grade-student-search");
  searchInput.addEventListener("input", () => {
    const searchTerm = searchInput.value.toLowerCase();
    const filteredStudents = gradeStudents.filter(
      (student) =>
        student.name.toLowerCase().includes(searchTerm) ||
        student.parentEmail.toLowerCase().includes(searchTerm),
    );

    const tableBody = document.getElementById("grade-students-table-body");
    tableBody.innerHTML = renderGradeStudentsRows(filteredStudents);

    // Re-add event listeners to new elements
    addGradeStudentEventListeners();
  });

  // Add event listeners to initial elements
  addGradeStudentEventListeners();
}

// Render grade students table rows
function renderGradeStudentsRows(gradeStudents) {
  if (gradeStudents.length === 0) {
    return `
      <tr class="table-row">
        <td class="table-cell" colspan="10" style="text-align: center;">No students found for Grade ${selectedGradeLevel}.</td>
      </tr>
    `;
  }

  return gradeStudents
    .map((student) => {
      return `
      <tr class="table-row">
        <td class="table-cell">
          <input type="checkbox" class="checkbox grade-student-checkbox" 
            data-student-id="${student.id}" />
        </td>
        <td class="table-cell">${student.name}</td>
        <td class="table-cell">${student.parentEmail}</td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.q1)}">${student.q1}</span>
        </td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.q2)}">${student.q2}</span>
        </td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.q3)}">${student.q3}</span>
        </td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.q4)}">${student.q4}</span>
        </td>
        <td class="table-cell">
          <span class="badge ${getGradeStatusClass(student.average)}">${student.average.toFixed(1)}</span>
        </td>
        <td class="table-cell">
          <span class="badge badge-outline ${student.average >= 75 ? "badge-outline-green" : "badge-outline-red"}">
            ${student.average >= 75 ? "Passed" : "Failed"}
          </span>
        </td>
        <td class="table-cell">
          <div class="action-buttons">
            <button class="action-button action-button-amber grade-edit-student" data-student-id="${student.id}">
              ✏️
            </button>
            <button class="action-button action-button-red grade-delete-student" data-student-id="${student.id}">
              🗑️
            </button>
          </div>
        </td>
      </tr>
    `;
    })
    .join("");
}

// Add event listeners to grade student elements
function addGradeStudentEventListeners() {
  document.querySelectorAll(".grade-edit-student").forEach((button) => {
    button.addEventListener("click", () => {
      const studentId = button.getAttribute("data-student-id");
      const student = students.find((s) => s.id === studentId);
      handleEditStudent(student);
    });
  });

  document.querySelectorAll(".grade-delete-student").forEach((button) => {
    button.addEventListener("click", () => {
      const studentId = button.getAttribute("data-student-id");
      handleDeleteStudent(studentId);
    });
  });
}

// Calculate grade level statistics
function calculateGradeLevelStats(gradeStudents) {
  if (gradeStudents.length === 0) {
    return { count: 0, avgScore: 0, passing: 0, failing: 0 };
  }

  const totalAverage = gradeStudents.reduce(
    (sum, student) => sum + student.average,
    0,
  );
  const avgScore = totalAverage / gradeStudents.length;
  const passing = gradeStudents.filter(
    (student) => student.average >= 75,
  ).length;
  const failing = gradeStudents.length - passing;

  return {
    count: gradeStudents.length,
    avgScore: avgScore.toFixed(1),
    passing,
    failing,
  };
}

// Handle edit student
function handleEditStudent(student) {
  // In a real implementation, this would open a modal
  // For simplicity, we'll use prompt dialogs
  const updatedName = prompt("Enter updated student name:", student.name);
  const updatedEmail = prompt(
    "Enter updated parent email:",
    student.parentEmail,
  );
  const updatedQ1 = parseInt(
    prompt("Enter Q1 grade:", student.q1.toString()) || "0",
  );
  const updatedQ2 = parseInt(
    prompt("Enter Q2 grade:", student.q2.toString()) || "0",
  );
  const updatedQ3 = parseInt(
    prompt("Enter Q3 grade:", student.q3.toString()) || "0",
  );
  const updatedQ4 = parseInt(
    prompt("Enter Q4 grade:", student.q4.toString()) || "0",
  );

  if (updatedName && updatedEmail) {
    const updatedAverage = (updatedQ1 + updatedQ2 + updatedQ3 + updatedQ4) / 4;

    const updatedStudents = students.map((s) => {
      if (s.id === student.id) {
        return {
          ...s,
          name: updatedName,
          parentEmail: updatedEmail,
          q1: updatedQ1,
          q2: updatedQ2,
          q3: updatedQ3,
          q4: updatedQ4,
          average: updatedAverage,
        };
      }
      return s;
    });

    students = updatedStudents;
    localStorage.setItem("students", JSON.stringify(updatedStudents));
    alert(`Student ${updatedName} updated successfully`);

    // Refresh the views
    if (document.getElementById("students-table-body")) {
      renderStudentTable();
    }

    if (document.getElementById("grade-students-table-body")) {
      renderGradeLevelContent(selectedGradeLevel);
    }
  }
}

// Handle delete student
function handleDeleteStudent(studentId) {
  if (confirm("Are you sure you want to delete this student?")) {
    const studentToDelete = students.find((s) => s.id === studentId);
    const updatedStudents = students.filter((s) => s.id !== studentId);

    students = updatedStudents;
    localStorage.setItem("students", JSON.stringify(updatedStudents));
    alert(`Student ${studentToDelete.name} deleted successfully`);

    // Refresh the views
    if (document.getElementById("students-table-body")) {
      renderStudentTable();
    }

    if (document.getElementById("grade-students-table-body")) {
      renderGradeLevelContent(selectedGradeLevel);
    }
  }
}

// Render student portal
function renderStudentPortal() {
  app.innerHTML = `
    <div class="dashboard">
      <div class="dashboard-header">
        <h1 class="dashboard-title">Student Portal</h1>
        <button id="logout-button" class="logout-button">
          <span>🚪</span> Logout
        </button>
      </div>
      
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Grade Level</h2>
          <p class="card-description">Select a grade level to view students</p>
        </div>
        <div class="card-content">
          <div class="tabs-list">
            <div class="tab-trigger active" data-tab="grade-7">Grade 7</div>
            <div class="tab-trigger" data-tab="grade-8">Grade 8</div>
            <div class="tab-trigger" data-tab="grade-9">Grade 9</div>
            <div class="tab-trigger" data-tab="grade-10">Grade 10</div>
          </div>
        </div>
      </div>
      
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Student Search</h2>
          <p class="card-description">Find students by name or ID</p>
        </div>
        <div class="card-content">
          <div class="search-container">
            <input id="student-portal-search" class="search-input" placeholder="Search students..." />
            <span class="search-icon">🔍</span>
          </div>
        </div>
      </div>
      
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Student Records - Grade 7</h2>
          <p class="card-description" id="student-count">0 students found</p>
        </div>
        <div class="card-content">
          <div class="tabs-list">
            <div class="tab-trigger active" data-tab="overview">Overview</div>
            <div class="tab-trigger" data-tab="details">Subject Details</div>
          </div>
          
          <div class="tab-content active" id="overview-tab">
            <div class="table-container">
              <table class="table">
                <thead class="table-header">
                  <tr>
                    <th>Student</th>
                    <th>ID</th>
                    <th>Q1</th>
                    <th>Q2</th>
                    <th>Q3</th>
                    <th>Q4</th>
                    <th>Average</th>
                    <th>Contact</th>
                  </tr>
                </thead>
                <tbody id="student-portal-table-body">
                  <!-- Student rows will be inserted here -->
                </tbody>
              </table>
            </div>
          </div>
          
          <div class="tab-content" id="details-tab">
            <div id="student-details-container">
              <!-- Student details will be inserted here -->
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  // Add event listeners
  document
    .getElementById("logout-button")
    .addEventListener("click", handleLogout);

  // Tab switching for main tabs
  const tabTriggers = document.querySelectorAll(".tab-trigger");
  tabTriggers.forEach((trigger) => {
    trigger.addEventListener("click", () => {
      const tabName = trigger.getAttribute("data-tab");

      // Find the parent tabs-list
      const tabsList = trigger.closest(".tabs-list");

      // Update active trigger in this list
      tabsList
        .querySelectorAll(".tab-trigger")
        .forEach((t) => t.classList.remove("active"));
      trigger.classList.add("active");

      // If this is the main content tab list
      if (tabName === "overview" || tabName === "details") {
        document
          .querySelectorAll(".card-content > .tab-content")
          .forEach((content) => content.classList.remove("active"));
        document.getElementById(`${tabName}-tab`).classList.add("active");
      } else if (tabName.startsWith("grade-")) {
        // Handle grade level tabs
        const gradeNumber = parseInt(tabName.split("-")[1]);
        selectedGradeLevel = gradeNumber;
        document.querySelector(".card-title").textContent =
          `Student Records - Grade ${gradeNumber}`;
        renderStudentPortalTable();
      }
    });
  });

  // Search functionality
  const searchInput = document.getElementById("student-portal-search");
  searchInput.addEventListener("input", () => {
    renderStudentPortalTable();
  });

  // Initial render
  renderStudentPortalTable();
}

// Render student portal table
function renderStudentPortalTable() {
  const searchTerm = document
    .getElementById("student-portal-search")
    .value.toLowerCase();

  // Generate sample data for the selected grade
  const gradeStudents = generateGradeStudents(selectedGradeLevel).filter(
    (student) =>
      student.name.toLowerCase().includes(searchTerm) ||
      student.id.toLowerCase().includes(searchTerm),
  );

  // Update student count
  document.getElementById("student-count").textContent =
    `${gradeStudents.length} students found`;

  const tableBody = document.getElementById("student-portal-table-body");

  if (gradeStudents.length === 0) {
    tableBody.innerHTML = `
      <tr class="table-row">
        <td class="table-cell" colspan="8" style="text-align: center;">No students found.</td>
      </tr>
    `;
    document.getElementById("student-details-container").innerHTML = `
      <div style="text-align: center; padding: 2rem; color: #888888;">
        No students found. Try adjusting your search.
      </div>
    `;
    return;
  }

  tableBody.innerHTML = gradeStudents
    .map((student) => {
      const average = calculateAverage(student.grades);
      const averageStatus =
        average !== null
          ? getGradeStatus(average)
          : { label: "N/A", variant: "outline" };

      return `
      <tr class="table-row">
        <td class="table-cell">${student.name}</td>
        <td class="table-cell">${student.id}</td>
        <td class="table-cell">
          ${
            student.grades.q1 !== null
              ? `<span class="badge ${getBadgeClass(getGradeStatus(student.grades.q1).variant)}">${student.grades.q1}</span>`
              : "N/A"
          }
        </td>
        <td class="table-cell">
          ${
            student.grades.q2 !== null
              ? `<span class="badge ${getBadgeClass(getGradeStatus(student.grades.q2).variant)}">${student.grades.q2}</span>`
              : "N/A"
          }
        </td>
        <td class="table-cell">
          ${
            student.grades.q3 !== null
              ? `<span class="badge ${getBadgeClass(getGradeStatus(student.grades.q3).variant)}">${student.grades.q3}</span>`
              : "N/A"
          }
        </td>
        <td class="table-cell">
          ${
            student.grades.q4 !== null
              ? `<span class="badge ${getBadgeClass(getGradeStatus(student.grades.q4).variant)}">${student.grades.q4}</span>`
              : "N/A"
          }
        </td>
        <td class="table-cell">
          ${
            average !== null
              ? `<span class="badge ${getBadgeClass(averageStatus.variant)}">${average}</span>`
              : "N/A"
          }
        </td>
        <td class="table-cell">
          <button class="action-button action-button-blue email-parent" data-email="${student.parentEmail}">
            ✉️ Email
          </button>
        </td>
      </tr>
    `;
    })
    .join("");

  // Render student details
  document.getElementById("student-details-container").innerHTML = gradeStudents
    .map((student) => {
      return `
      <div class="card" style="margin-bottom: 1rem;">
        <div class="card-header">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <h3 class="card-title">${student.name}</h3>
            <span class="badge badge-outline">${student.id}</span>
          </div>
          <p class="card-description">Parent Email: ${student.parentEmail}</p>
        </div>
        <div class="card-content">
          <div class="tabs-list">
            <div class="tab-trigger active" data-tab="q1-${student.id}">1st Quarter</div>
            <div class="tab-trigger" data-tab="q2-${student.id}">2nd Quarter</div>
            <div class="tab-trigger" data-tab="q3-${student.id}">3rd Quarter</div>
            <div class="tab-trigger" data-tab="q4-${student.id}">4th Quarter</div>
            <div class="tab-trigger" data-tab="all-${student.id}">All Quarters</div>
          </div>
          
          <div class="tab-content active" id="q1-${student.id}-tab">
            ${renderSubjectTable(student, "q1")}
          </div>
          
          <div class="tab-content" id="q2-${student.id}-tab">
            ${renderSubjectTable(student, "q2")}
          </div>
          
          <div class="tab-content" id="q3-${student.id}-tab">
            ${renderSubjectTable(student, "q3")}
          </div>
          
          <div class="tab-content" id="q4-${student.id}-tab">
            ${renderSubjectTable(student, "q4")}
          </div>
          
          <div class="tab-content" id="all-${student.id}-tab">
            ${renderAllQuartersTable(student)}
          </div>
        </div>
      </div>
    `;
    })
    .join("");

  // Add event listeners for student detail tabs
  document
    .querySelectorAll("#student-details-container .tab-trigger")
    .forEach((trigger) => {
      trigger.addEventListener("click", () => {
        const tabName = trigger.getAttribute("data-tab");
        const studentId = tabName.split("-")[1];
        const quarter = tabName.split("-")[0];

        // Find the parent tabs-list
        const tabsList = trigger.closest(".tabs-list");

        // Update active trigger in this list
        tabsList
          .querySelectorAll(".tab-trigger")
          .forEach((t) => t.classList.remove("active"));
        trigger.classList.add("active");

        // Show the corresponding tab content
        const cardContent = trigger.closest(".card-content");
        cardContent
          .querySelectorAll(".tab-content")
          .forEach((content) => content.classList.remove("active"));
        document.getElementById(`${tabName}-tab`).classList.add("active");
      });
    });

  // Add event listeners for email buttons
  document.querySelectorAll(".email-parent").forEach((button) => {
    button.addEventListener("click", () => {
      const email = button.getAttribute("data-email");
      alert(`Email would be sent to ${email}`);
    });
  });
}

// Render subject table for a specific quarter
function renderSubjectTable(student, quarter) {
  return `
    <div class="table-container">
      <table class="table">
        <thead class="table-header">
          <tr>
            <th>Subject</th>
            <th>Grade</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${student.subjects
            .map((subject) => {
              const gradeStatus = getGradeStatus(subject.grades[quarter]);
              return `
              <tr class="table-row">
                <td class="table-cell">${subject.name}</td>
                <td class="table-cell">
                  ${
                    subject.grades[quarter] !== null
                      ? `<span class="badge ${getBadgeClass(gradeStatus.variant)}">${subject.grades[quarter]}</span>`
                      : "N/A"
                  }
                </td>
                <td class="table-cell">${gradeStatus.label}</td>
              </tr>
            `;
            })
            .join("")}
        </tbody>
      </table>
    </div>
  `;
}

// Render all quarters table
function renderAllQuartersTable(student) {
  return `
    <div class="table-container">
      <table class="table">
        <thead class="table-header">
          <tr>
            <th>Subject</th>
            <th>Q1</th>
            <th>Q2</th>
            <th>Q3</th>
            <th>Q4</th>
            <th>Average</th>
          </tr>
        </thead>
        <tbody>
          ${student.subjects
            .map((subject) => {
              const average = calculateAverage(subject.grades);
              const averageStatus =
                average !== null
                  ? getGradeStatus(average)
                  : { label: "N/A", variant: "outline" };

              return `
              <tr class="table-row">
                <td class="table-cell">${subject.name}</td>
                <td class="table-cell">
                  ${
                    subject.grades.q1 !== null
                      ? `<span class="badge ${getBadgeClass(getGradeStatus(subject.grades.q1).variant)}">${subject.grades.q1}</span>`
                      : "N/A"
                  }
                </td>
                <td class="table-cell">
                  ${
                    subject.grades.q2 !== null
                      ? `<span class="badge ${getBadgeClass(getGradeStatus(subject.grades.q2).variant)}">${subject.grades.q2}</span>`
                      : "N/A"
                  }
                </td>
                <td class="table-cell">
                  ${
                    subject.grades.q3 !== null
                      ? `<span class="badge ${getBadgeClass(getGradeStatus(subject.grades.q3).variant)}">${subject.grades.q3}</span>`
                      : "N/A"
                  }
                </td>
                <td class="table-cell">
                  ${
                    subject.grades.q4 !== null
                      ? `<span class="badge ${getBadgeClass(getGradeStatus(subject.grades.q4).variant)}">${subject.grades.q4}</span>`
                      : "N/A"
                  }
                </td>
                <td class="table-cell">
                  ${
                    average !== null
                      ? `<span class="badge ${getBadgeClass(averageStatus.variant)}">${average}</span>`
                      : "N/A"
                  }
                </td>
              </tr>
            `;
            })
            .join("")}
        </tbody>
      </table>
    </div>
  `;
}

// Generate grade students
function generateGradeStudents(gradeLevel) {
  const students = [];

  // Generate 10 students per grade
  for (let i = 1; i <= 10; i++) {
    const subjects = [
      "Math",
      "Science",
      "MAPEH",
      "TLE",
      "AP",
      "ESP",
      "Filipino",
      "English",
    ].map((subjectName) => ({
      name: subjectName,
      grades: {
        q1: Math.floor(Math.random() * 30) + 70,
        q2: Math.floor(Math.random() * 30) + 70,
        q3: Math.floor(Math.random() * 30) + 70,
        q4: Math.floor(Math.random() * 30) + 70,
      },
    }));

    students.push({
      id: `G${gradeLevel}-${i}`,
      name: `Student ${i} (Grade ${gradeLevel})`,
      parentEmail: `parent${i}@example.com`,
      grades: {
        q1: Math.floor(Math.random() * 30) + 70,
        q2: Math.floor(Math.random() * 30) + 70,
        q3: Math.floor(Math.random() * 30) + 70,
        q4: Math.floor(Math.random() * 30) + 70,
      },
      subjects: subjects,
    });
  }

  // Add the current user if they are a student
  if (currentUser && currentUser.role === "student") {
    const subjects = [
      "Math",
      "Science",
      "MAPEH",
      "TLE",
      "AP",
      "ESP",
      "Filipino",
      "English",
    ].map((subjectName) => ({
      name: subjectName,
      grades: {
        q1: Math.floor(Math.random() * 30) + 70,
        q2: Math.floor(Math.random() * 30) + 70,
        q3: Math.floor(Math.random() * 30) + 70,
        q4: Math.floor(Math.random() * 30) + 70,
      },
    }));

    students.push({
      id: `S-${currentUser.username}`,
      name: currentUser.username,
      parentEmail: `${currentUser.username.toLowerCase()}@example.com`,
      grades: {
        q1: Math.floor(Math.random() * 30) + 70,
        q2: Math.floor(Math.random() * 30) + 70,
        q3: Math.floor(Math.random() * 30) + 70,
        q4: Math.floor(Math.random() * 30) + 70,
      },
      subjects: subjects,
    });
  }

  return students;
}

// Get grade status
function getGradeStatus(grade) {
  if (grade === null) return { label: "N/A", variant: "outline" };
  if (grade >= 90) return { label: "Excellent", variant: "default" };
  if (grade >= 80) return { label: "Good", variant: "secondary" };
  if (grade >= 70) return { label: "Average", variant: "default" };
  return { label: "Needs Improvement", variant: "destructive" };
}

// Get badge class based on variant
function getBadgeClass(variant) {
  switch (variant) {
    case "default":
      return "badge-green";
    case "secondary":
      return "badge-blue";
    case "destructive":
      return "badge-red";
    case "outline":
      return "badge-outline";
    default:
      return "";
  }
}

// Calculate average from grades
function calculateAverage(grades) {
  const validGrades = [grades.q1, grades.q2, grades.q3, grades.q4].filter(
    (g) => g !== null,
  );
  if (validGrades.length === 0) return null;
  return Math.round(
    validGrades.reduce((sum, grade) => sum + grade, 0) / validGrades.length,
  );
}

// Handle logout
function handleLogout() {
  localStorage.removeItem("currentUser");
  currentUser = null;
  renderAuth();
}

// Show error message
function showError(elementId, message) {
  const errorElement = document.getElementById(elementId);
  errorElement.textContent = message;
  errorElement.style.display = "block";
}

// Initialize the app when the DOM is loaded
document.addEventListener("DOMContentLoaded", initApp);
