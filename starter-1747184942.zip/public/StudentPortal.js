document.addEventListener("DOMContentLoaded", function () {
  // DOM Elements
  const logoutBtn = document.getElementById("logoutBtn");
  const gradeLevelButtons = document.getElementById("gradeLevelButtons");
  const searchInput = document.getElementById("searchInput");
  const selectedGradeLevelEl = document.getElementById("selectedGradeLevel");
  const studentCountEl = document.getElementById("studentCount");
  const overviewTableBody = document.getElementById("overviewTableBody");
  const studentDetails = document.getElementById("studentDetails");
  const tabTriggers = document.querySelectorAll(".tab-trigger");

  // State
  let gradeLevels = [];
  let selectedGradeLevel = "";
  let searchQuery = "";
  let activeTab = "overview";

  // Initialize
  initializeApp();

  // Event Listeners
  logoutBtn.addEventListener("click", handleLogout);
  searchInput.addEventListener("input", handleSearch);

  tabTriggers.forEach((trigger) => {
    trigger.addEventListener("click", function () {
      const tabId = this.getAttribute("data-tab");
      setActiveTab(tabId);
    });
  });

  // Functions
  function initializeApp() {
    gradeLevels = generateSampleStudents();
    selectedGradeLevel = gradeLevels[0].level;
    selectedGradeLevelEl.textContent = selectedGradeLevel;

    renderGradeLevelButtons();
    renderStudentData();
  }

  function renderGradeLevelButtons() {
    gradeLevelButtons.innerHTML = "";

    gradeLevels.forEach((gradeLevel) => {
      const button = document.createElement("button");
      button.className = `grade-btn ${selectedGradeLevel === gradeLevel.level ? "active" : ""}`;
      button.textContent = gradeLevel.level;

      button.addEventListener("click", function () {
        selectedGradeLevel = gradeLevel.level;
        selectedGradeLevelEl.textContent = selectedGradeLevel;

        // Update active button
        document.querySelectorAll(".grade-btn").forEach((btn) => {
          btn.classList.remove("active");
        });
        this.classList.add("active");

        renderStudentData();
      });

      gradeLevelButtons.appendChild(button);
    });
  }

  function renderStudentData() {
    const filteredStudents = getFilteredStudents();
    studentCountEl.textContent = filteredStudents.length;

    renderOverviewTab(filteredStudents);
    renderDetailsTab(filteredStudents);
  }

  function getFilteredStudents() {
    const gradeLevel = gradeLevels.find(
      (gl) => gl.level === selectedGradeLevel,
    );
    if (!gradeLevel) return [];

    return gradeLevel.students.filter(
      (student) =>
        student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.id.toLowerCase().includes(searchQuery.toLowerCase()),
    );
  }

  function renderOverviewTab(students) {
    overviewTableBody.innerHTML = "";

    if (students.length === 0) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 8;
      cell.className = "empty-message";
      cell.textContent = "No students found.";
      row.appendChild(cell);
      overviewTableBody.appendChild(row);
      return;
    }

    students.forEach((student) => {
      const average = calculateAverage(student.grades);
      const averageStatus =
        average !== null
          ? getGradeStatus(average)
          : { label: "N/A", variant: "outline" };

      const row = document.createElement("tr");

      // Student name
      const nameCell = document.createElement("td");
      nameCell.className = "student-name";
      nameCell.textContent = student.name;
      row.appendChild(nameCell);

      // Student ID
      const idCell = document.createElement("td");
      idCell.className = "student-id";
      idCell.textContent = student.id;
      row.appendChild(idCell);

      // Q1-Q4 grades
      ["q1", "q2", "q3", "q4"].forEach((quarter) => {
        const cell = document.createElement("td");
        if (student.grades[quarter] !== null) {
          const badge = document.createElement("span");
          const status = getGradeStatus(student.grades[quarter]);
          badge.className = `badge badge-${status.variant}`;
          badge.textContent = student.grades[quarter];
          cell.appendChild(badge);
        } else {
          cell.textContent = "N/A";
        }
        row.appendChild(cell);
      });

      // Average
      const avgCell = document.createElement("td");
      if (average !== null) {
        const badge = document.createElement("span");
        badge.className = `badge badge-${averageStatus.variant}`;
        badge.textContent = average;
        avgCell.appendChild(badge);
      } else {
        avgCell.textContent = "N/A";
      }
      row.appendChild(avgCell);

      // Contact
      const contactCell = document.createElement("td");
      const emailBtn = document.createElement("button");
      emailBtn.className = "email-btn";
      emailBtn.innerHTML = '<span class="icon mail-icon"></span> Email';
      emailBtn.addEventListener("click", () =>
        handleSendEmail(student.parentEmail),
      );
      contactCell.appendChild(emailBtn);
      row.appendChild(contactCell);

      overviewTableBody.appendChild(row);
    });
  }

  function renderDetailsTab(students) {
    studentDetails.innerHTML = "";

    if (students.length === 0) {
      const emptyMessage = document.createElement("div");
      emptyMessage.className = "empty-message";
      emptyMessage.textContent =
        "No students found. Try adjusting your search.";
      studentDetails.appendChild(emptyMessage);
      return;
    }

    students.forEach((student) => {
      // Create student card
      const card = document.createElement("div");
      card.className = "student-detail-card";

      // Card header
      const header = document.createElement("div");
      header.className = "student-detail-header";

      const titleContainer = document.createElement("div");
      const title = document.createElement("h3");
      title.className = "student-detail-title";
      title.textContent = student.name;
      titleContainer.appendChild(title);

      const idBadge = document.createElement("span");
      idBadge.className = "badge badge-outline";
      idBadge.textContent = student.id;

      const headerFlex = document.createElement("div");
      headerFlex.className = "header-flex";
      headerFlex.appendChild(title);
      headerFlex.appendChild(idBadge);

      const description = document.createElement("p");
      description.className = "card-description";
      description.textContent = `Parent Email: ${student.parentEmail}`;

      header.appendChild(headerFlex);
      header.appendChild(description);
      card.appendChild(header);

      // Card content
      const content = document.createElement("div");
      content.className = "student-detail-content";

      // Quarter tabs
      const quarterTabs = document.createElement("div");
      quarterTabs.className = "quarter-tabs";

      const quarterTabsList = document.createElement("div");
      quarterTabsList.className = "quarter-tabs-list";

      const quarters = ["q1", "q2", "q3", "q4", "all"];
      const quarterLabels = {
        q1: "1st Quarter",
        q2: "2nd Quarter",
        q3: "3rd Quarter",
        q4: "4th Quarter",
        all: "All Quarters",
      };

      quarters.forEach((quarter, index) => {
        const trigger = document.createElement("button");
        trigger.className = `quarter-tab-trigger ${index === 0 ? "active" : ""}`;
        trigger.setAttribute("data-quarter", quarter);
        trigger.textContent = quarterLabels[quarter];

        trigger.addEventListener("click", function () {
          // Update active trigger
          quarterTabsList
            .querySelectorAll(".quarter-tab-trigger")
            .forEach((t) => {
              t.classList.remove("active");
            });
          this.classList.add("active");

          // Show corresponding content
          content.querySelectorAll(".quarter-tab-content").forEach((c) => {
            c.classList.remove("active");
          });
          content
            .querySelector(`.quarter-tab-content[data-quarter="${quarter}"]`)
            .classList.add("active");
        });

        quarterTabsList.appendChild(trigger);
      });

      quarterTabs.appendChild(quarterTabsList);
      content.appendChild(quarterTabs);

      // Create tab content for each quarter
      quarters.forEach((quarter, index) => {
        const tabContent = document.createElement("div");
        tabContent.className = `quarter-tab-content ${index === 0 ? "active" : ""}`;
        tabContent.setAttribute("data-quarter", quarter);

        // Implement the content for each tab
        if (quarter === "all") {
          // All quarters view - show all subjects with all quarter grades
          if (student.subjects && student.subjects.length > 0) {
            const subjectsTable = document.createElement("table");
            subjectsTable.className = "data-table";

            // Create table header
            const tableHead = document.createElement("thead");
            const headerRow = document.createElement("tr");

            const subjectHeader = document.createElement("th");
            subjectHeader.textContent = "Subject";
            headerRow.appendChild(subjectHeader);

            ["Q1", "Q2", "Q3", "Q4", "Average"].forEach((quarter) => {
              const quarterHeader = document.createElement("th");
              quarterHeader.textContent = quarter;
              headerRow.appendChild(quarterHeader);
            });

            tableHead.appendChild(headerRow);
            subjectsTable.appendChild(tableHead);

            // Create table body
            const tableBody = document.createElement("tbody");

            student.subjects.forEach((subject) => {
              const subjectRow = document.createElement("tr");

              // Subject name
              const nameCell = document.createElement("td");
              nameCell.textContent = subject.name;
              subjectRow.appendChild(nameCell);

              // Quarter grades
              ["q1", "q2", "q3", "q4"].forEach((q) => {
                const gradeCell = document.createElement("td");
                if (subject.grades[q] !== null) {
                  const badge = document.createElement("span");
                  const status = getGradeStatus(subject.grades[q]);
                  badge.className = `badge badge-${status.variant}`;
                  badge.textContent = subject.grades[q];
                  gradeCell.appendChild(badge);
                } else {
                  gradeCell.textContent = "N/A";
                }
                subjectRow.appendChild(gradeCell);
              });

              // Average
              const avgCell = document.createElement("td");
              const average = calculateAverage(subject.grades);
              if (average !== null) {
                const badge = document.createElement("span");
                const status = getGradeStatus(average);
                badge.className = `badge badge-${status.variant}`;
                badge.textContent = average;
                avgCell.appendChild(badge);
              } else {
                avgCell.textContent = "N/A";
              }
              subjectRow.appendChild(avgCell);

              tableBody.appendChild(subjectRow);
            });

            subjectsTable.appendChild(tableBody);
            tabContent.appendChild(subjectsTable);
          } else {
            const noSubjects = document.createElement("p");
            noSubjects.textContent = "No subject data available.";
            tabContent.appendChild(noSubjects);
          }
        } else {
          // Single quarter view - show all subjects for this quarter
          if (student.subjects && student.subjects.length > 0) {
            const quarterTable = document.createElement("table");
            quarterTable.className = "data-table";

            // Create table header
            const tableHead = document.createElement("thead");
            const headerRow = document.createElement("tr");

            ["Subject", "Grade", "Status"].forEach((col) => {
              const header = document.createElement("th");
              header.textContent = col;
              headerRow.appendChild(header);
            });

            tableHead.appendChild(headerRow);
            quarterTable.appendChild(tableHead);

            // Create table body
            const tableBody = document.createElement("tbody");

            student.subjects.forEach((subject) => {
              const subjectRow = document.createElement("tr");

              // Subject name
              const nameCell = document.createElement("td");
              nameCell.textContent = subject.name;
              subjectRow.appendChild(nameCell);

              // Grade
              const gradeCell = document.createElement("td");
              if (subject.grades[quarter] !== null) {
                const badge = document.createElement("span");
                badge.className = "badge badge-default";
                badge.textContent = subject.grades[quarter];
                gradeCell.appendChild(badge);
              } else {
                gradeCell.textContent = "N/A";
              }
              subjectRow.appendChild(gradeCell);

              // Status
              const statusCell = document.createElement("td");
              if (subject.grades[quarter] !== null) {
                const status = getGradeStatus(subject.grades[quarter]);
                statusCell.textContent = status.label;
              } else {
                statusCell.textContent = "N/A";
              }
              subjectRow.appendChild(statusCell);

              tableBody.appendChild(subjectRow);
            });

            quarterTable.appendChild(tableBody);
            tabContent.appendChild(quarterTable);
          } else {
            const noSubjects = document.createElement("p");
            noSubjects.textContent =
              "No subject data available for this quarter.";
            tabContent.appendChild(noSubjects);
          }
        }

        content.appendChild(tabContent);
      });

      card.appendChild(content);
      studentDetails.appendChild(card);
    });
  }

  function setActiveTab(tabId) {
    activeTab = tabId;

    // Update active trigger
    tabTriggers.forEach((trigger) => {
      trigger.classList.remove("active");
      if (trigger.getAttribute("data-tab") === tabId) {
        trigger.classList.add("active");
      }
    });

    // Show corresponding content
    document.querySelectorAll(".tab-content").forEach((content) => {
      content.classList.remove("active");
    });
    document.getElementById(`${tabId}Tab`).classList.add("active");
  }

  function handleSearch(e) {
    searchQuery = e.target.value;
    renderStudentData();
  }

  function handleLogout() {
    localStorage.removeItem("currentUser");
    window.location.href = "/";
  }

  function handleSendEmail(email) {
    console.log(`Sending email to ${email}`);
    alert(`Email would be sent to ${email}`);
  }

  // Helper functions
  function generateSampleStudents() {
    const gradeLevels = [];

    // Get registered students from localStorage
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const registeredStudents = users.filter((user) => user.role === "student");

    // Generate sample data for grades 7-10
    for (let grade = 7; grade <= 10; grade++) {
      const students = [];

      // Generate 10 students per grade
      for (let i = 1; i <= 10; i++) {
        const subjects = [
          "Math",
          "Science",
          "MAPEH",
          "TLE",
          "AP",
          "ESP",
          "Filipino",
          "English",
        ].map((subjectName) => ({
          name: subjectName,
          grades: {
            q1: Math.floor(Math.random() * 30) + 70,
            q2: Math.floor(Math.random() * 30) + 70,
            q3: Math.floor(Math.random() * 30) + 70,
            q4: Math.floor(Math.random() * 30) + 70,
          },
        }));

        students.push({
          id: `G${grade}-${i}`,
          name: `Student ${i} (Grade ${grade})`,
          parentEmail: `parent${i}@example.com`,
          grades: {
            q1: Math.floor(Math.random() * 30) + 70,
            q2: Math.floor(Math.random() * 30) + 70,
            q3: Math.floor(Math.random() * 30) + 70,
            q4: Math.floor(Math.random() * 30) + 70,
          },
          subjects: subjects,
        });
      }

      // Add registered students to grade 7 (for demonstration)
      if (grade === 7 && registeredStudents.length > 0) {
        registeredStudents.forEach((student, index) => {
          const subjects = [
            "Math",
            "Science",
            "MAPEH",
            "TLE",
            "AP",
            "ESP",
            "Filipino",
            "English",
          ].map((subjectName) => ({
            name: subjectName,
            grades: {
              q1: Math.floor(Math.random() * 30) + 70,
              q2: Math.floor(Math.random() * 30) + 70,
              q3: Math.floor(Math.random() * 30) + 70,
              q4: Math.floor(Math.random() * 30) + 70,
            },
          }));

          students.push({
            id: `RS-${index + 1}`,
            name: student.username,
            parentEmail: student.email || `${student.username}@example.com`,
            grades: {
              q1: Math.floor(Math.random() * 30) + 70,
              q2: Math.floor(Math.random() * 30) + 70,
              q3: Math.floor(Math.random() * 30) + 70,
              q4: Math.floor(Math.random() * 30) + 70,
            },
            subjects: subjects,
          });
        });
      }

      gradeLevels.push({
        level: `Grade ${grade}`,
        students: students,
      });
    }

    return gradeLevels;
  }

  function getGradeStatus(grade) {
    if (grade === null) return { label: "N/A", variant: "outline" };
    if (grade >= 90) return { label: "Excellent", variant: "default" };
    if (grade >= 80) return { label: "Good", variant: "secondary" };
    if (grade >= 70) return { label: "Average", variant: "default" };
    return { label: "Needs Improvement", variant: "destructive" };
  }

  function calculateAverage(grades) {
    const validGrades = [grades.q1, grades.q2, grades.q3, grades.q4].filter(
      (g) => g !== null,
    );
    if (validGrades.length === 0) return null;
    return Math.round(
      validGrades.reduce((sum, grade) => sum + grade, 0) / validGrades.length,
    );
  }
});
