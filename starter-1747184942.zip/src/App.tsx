import { Suspense, useEffect, useState } from "react";
import { useRoutes, Routes, Route, Navigate } from "react-router-dom";
import Home from "./components/Dashboard";
import Auth from "./components/Auth";
import AdminDashboard from "./components/AdminDashboard";
import StudentPortal from "./components/StudentPortal";
import routes from "tempo-routes";
import { ThemeProvider } from "./components/ThemeProvider";

function App() {
  const [user, setUser] = useState<{ username: string; role: string } | null>(
    null,
  );

  useEffect(() => {
    // Check if user is logged in
    const userStr = localStorage.getItem("currentUser");
    if (userStr) {
      setUser(JSON.parse(userStr));
    }
  }, []);

  const handleLogin = (userData: { username: string; role: string }) => {
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem("currentUser");
    setUser(null);
  };

  return (
    <ThemeProvider>
      <Suspense
        fallback={
          <div className="flex items-center justify-center min-h-screen bg-gray-900 dark:bg-gray-900 light:bg-gray-100">
            <p className="text-white dark:text-white light:text-gray-900 text-xl">
              Loading...
            </p>
          </div>
        }
      >
        <>
          <Routes>
            <Route
              path="/"
              element={
                user ? (
                  user.role === "admin" ? (
                    <Navigate to="/home" />
                  ) : (
                    <Navigate to="/home" />
                  )
                ) : (
                  <Auth onLogin={handleLogin} />
                )
              }
            />
            <Route
              path="/admin"
              element={<AdminDashboard onLogout={handleLogout} />}
            />
            <Route
              path="/student"
              element={<StudentPortal onLogout={handleLogout} />}
            />
            <Route path="/home" element={<Home />} />
            {import.meta.env.VITE_TEMPO === "true" && (
              <Route path="/tempobook/*" />
            )}
          </Routes>
          {import.meta.env.VITE_TEMPO === "true" && useRoutes(routes)}
        </>
      </Suspense>
    </ThemeProvider>
  );
}

export default App;
