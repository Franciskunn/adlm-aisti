// This is a mock email service that would be replaced with a real email service in production

export interface EmailDetails {
  from: string;
  to: string;
  subject: string;
  body: string;
}

export const sendEmail = async (details: EmailDetails): Promise<boolean> => {
  // In a real app, this would use an email API like SendGrid, Mailgun, etc.
  console.log("Sending email:", details);

  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      // Simulate successful email sending
      console.log("Email sent successfully");
      resolve(true);
    }, 1000);
  });
};

export const sendGradeReport = async (
  parentEmail: string,
  studentName: string,
  grades: any,
): Promise<boolean> => {
  const details: EmailDetails = {
    from: "depedamba@gmail.com",
    to: parentEmail,
    subject: `ALDM Grade Report for ${studentName}`,
    body: `
Dear Parent/Guardian,

Please find below the current grades for ${studentName}:

Quarter 1: ${grades.q1 || "N/A"}
Quarter 2: ${grades.q2 || "N/A"}
Quarter 3: ${grades.q3 || "N/A"}
Quarter 4: ${grades.q4 || "N/A"}
Average: ${grades.average ? grades.average.toFixed(1) : "N/A"}

For more details, please log in to the ALDM Grade Tracking System.

Thank you,
ALDM School Administration
    `,
  };

  return sendEmail(details);
};

export const sendVerificationCode = async (
  email: string,
  code: string,
): Promise<boolean> => {
  const details: EmailDetails = {
    from: "depedamba@gmail.com",
    to: email,
    subject: "ALDM Grade Tracking System - Verification Code",
    body: `
Your verification code is: ${code}

This code will expire in 10 minutes.

Thank you for registering with ALDM Grade Tracking System.
    `,
  };

  return sendEmail(details);
};
