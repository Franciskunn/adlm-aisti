import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import {
  Eye,
  EyeOff,
  Lock,
  Mail,
  User,
  CheckCircle2,
  ShieldCheck,
} from "lucide-react";

interface AuthProps {
  onLogin?: (userData: { username: string; role: string }) => void;
}

interface UserData {
  username: string;
  password: string;
  email?: string;
  role: "admin" | "student";
}

const Auth = ({ onLogin = () => {} }: AuthProps) => {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [generatedCode, setGeneratedCode] = useState("");
  const [showVerification, setShowVerification] = useState(false);
  const navigate = useNavigate();

  // Login form state
  const [loginData, setLoginData] = useState({
    username: "",
    password: "",
  });

  // Register form state
  const [registerData, setRegisterData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  // Initialize admin account on first load
  useEffect(() => {
    const users = JSON.parse(localStorage.getItem("users") || "[]");

    // Check if admin account exists
    const adminExists = users.some((user: UserData) => user.role === "admin");

    if (!adminExists) {
      // Create admin account
      const adminUser = {
        username: "DepedAmba",
        password: "Ambalayat@123",
        role: "admin",
      };

      localStorage.setItem("users", JSON.stringify([...users, adminUser]));
    }
  }, []);

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLoginData({ ...loginData, [name]: value });
    setError("");
  };

  const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setRegisterData({ ...registerData, [name]: value });
    setError("");
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    // Check for empty fields
    if (!loginData.username || !loginData.password) {
      setError("Please fill in all fields");
      return;
    }

    // Get users from localStorage
    const users = JSON.parse(localStorage.getItem("users") || "[]");

    // Find user
    const user = users.find(
      (u: UserData) =>
        u.username === loginData.username && u.password === loginData.password,
    );

    if (user) {
      // Set current user in localStorage
      localStorage.setItem(
        "currentUser",
        JSON.stringify({
          username: user.username,
          role: user.role,
        }),
      );

      // Call onLogin callback
      onLogin({ username: user.username, role: user.role });

      // Redirect based on role
      if (user.role === "admin") {
        navigate("/admin");
      } else {
        navigate("/student");
      }
    } else {
      setError("Invalid username or password");
    }
  };

  const generateVerificationCode = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedCode(code);
    return code;
  };

  const sendVerificationEmail = async (email: string, code: string) => {
    // In a real app, this would use an email API like SendGrid, Mailgun, etc.
    // For this demo, we're simulating the email sending
    console.log(`Sending verification code ${code} to ${email}`);

    // Simulate email sending with depedamba@gmail.com
    const emailDetails = {
      from: "depedamba@gmail.com",
      to: email,
      subject: "ALDM Grade Tracking System - Verification Code",
      body: `Your verification code is: ${code}\n\nThis code will expire in 10 minutes.\n\nThank you for registering with ALDM Grade Tracking System.`,
    };

    console.log("Email details:", emailDetails);

    // In a real app, we would call an API here
    return true;
  };

  const handleSendVerification = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (
      !registerData.username ||
      !registerData.email ||
      !registerData.password ||
      !registerData.confirmPassword
    ) {
      setError("Please fill in all fields");
      return;
    }

    if (registerData.password !== registerData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(registerData.email)) {
      setError("Please enter a valid email address");
      return;
    }

    // Check if username already exists
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    if (
      users.some((user: UserData) => user.username === registerData.username)
    ) {
      setError("Username already exists");
      return;
    }

    // Generate verification code
    const code = generateVerificationCode();
    setShowVerification(true);

    // Send verification email
    const emailSent = sendVerificationEmail(registerData.email, code);

    if (emailSent) {
      setSuccess(
        `Verification code sent to ${registerData.email}. For demo purposes, the code is: ${code}`,
      );
    } else {
      setError("Failed to send verification code. Please try again.");
      setShowVerification(false);
    }
  };

  const handleVerifyAndRegister = (e: React.FormEvent) => {
    e.preventDefault();

    if (verificationCode !== generatedCode) {
      setError("Invalid verification code");

      // Shake animation for error
      const codeInput = document.getElementById("verification-code");
      if (codeInput) {
        codeInput.classList.add("shake-animation");
        setTimeout(() => {
          codeInput.classList.remove("shake-animation");
        }, 500);
      }
      return;
    }

    // Add new user
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const newUser = {
      username: registerData.username,
      email: registerData.email,
      password: registerData.password,
      role: "student" as const,
    };

    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));

    // Show success message with animation
    setSuccess("Registration successful! You can now log in.");
    setRegisterData({
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    });

    // Create success animation
    const successAnimation = document.createElement("div");
    successAnimation.style.position = "fixed";
    successAnimation.style.top = "0";
    successAnimation.style.left = "0";
    successAnimation.style.width = "100%";
    successAnimation.style.height = "100%";
    successAnimation.style.backgroundColor = "rgba(16, 185, 129, 0.2)";
    successAnimation.style.display = "flex";
    successAnimation.style.justifyContent = "center";
    successAnimation.style.alignItems = "center";
    successAnimation.style.zIndex = "2000";
    successAnimation.style.opacity = "0";
    successAnimation.style.transition = "opacity 0.5s ease";

    const checkmark = document.createElement("div");
    checkmark.innerHTML = `<svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
    successAnimation.appendChild(checkmark);

    document.body.appendChild(successAnimation);

    setTimeout(() => {
      successAnimation.style.opacity = "1";
    }, 10);

    setTimeout(() => {
      successAnimation.style.opacity = "0";
      setTimeout(() => {
        document.body.removeChild(successAnimation);
        setActiveTab("login");
        setSuccess("");
        setShowVerification(false);
      }, 500);
    }, 1500);
  };

  // Logout handler to prevent blinking
  const handleLogout = (e: React.MouseEvent) => {
    e.preventDefault();
    localStorage.removeItem("currentUser");
    setTimeout(() => {
      navigate("/");
    }, 100);
  };

  // Admin shortcut key handler (Ctrl + A)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === "a") {
        e.preventDefault();
        navigate("/admin");
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [navigate]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-gray-900 to-gray-950 p-4">
      <style jsx>{`
        @keyframes shake {
          0%,
          100% {
            transform: translateX(0);
          }
          10%,
          30%,
          50%,
          70%,
          90% {
            transform: translateX(-5px);
          }
          20%,
          40%,
          60%,
          80% {
            transform: translateX(5px);
          }
        }
        .shake-animation {
          animation: shake 0.5s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
        }
        .card-hover {
          transition:
            transform 0.3s ease,
            box-shadow 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        .button-hover {
          transition: transform 0.2s ease;
        }
        .button-hover:active {
          transform: scale(0.95);
        }
      `}</style>
      <Card className="w-full max-w-md border border-indigo-500 bg-gray-800 text-white shadow-lg card-hover">
        <CardHeader className="bg-gradient-to-r from-blue-900 to-indigo-900 text-center">
          <CardTitle className="text-2xl font-bold text-center bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 bg-clip-text text-transparent">
            ALDM Grade Tracking System
          </CardTitle>
          <CardDescription className="text-gray-300">
            Enter your credentials to access your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs
            value={activeTab}
            onValueChange={(value) =>
              setActiveTab(value as "login" | "register")
            }
          >
            <TabsList className="grid w-full grid-cols-2 bg-gray-700">
              <TabsTrigger
                value="login"
                className="data-[state=active]:bg-gradient-to-r from-purple-500 to-pink-500"
              >
                Login
              </TabsTrigger>
              <TabsTrigger
                value="register"
                className="data-[state=active]:bg-gradient-to-r from-purple-500 to-pink-500"
              >
                Register
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="username" className="text-gray-300">
                    Username
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="username"
                      name="username"
                      placeholder="Enter your username"
                      value={loginData.username}
                      onChange={handleLoginChange}
                      className="pl-10 bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-gray-300">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={loginData.password}
                      onChange={handleLoginChange}
                      className="pl-10 pr-10 bg-gray-700 border-gray-600 text-white"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-gray-400 hover:text-gray-300"
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>

                {error && (
                  <div className="p-3 rounded-md bg-red-900/50 border border-red-500 text-red-300 text-sm">
                    {error}
                  </div>
                )}

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 hover:from-blue-600 hover:via-indigo-600 hover:to-purple-600 button-hover"
                >
                  Sign In
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="register">
              {error && (
                <div className="p-3 rounded-md bg-red-900/50 border border-red-500 text-red-300 text-sm mt-4">
                  {error}
                </div>
              )}

              {success && (
                <div className="p-3 rounded-md bg-green-900/50 border border-green-500 text-green-300 text-sm mt-4 flex items-start">
                  <CheckCircle2 className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                  <span>{success}</span>
                </div>
              )}

              {!showVerification ? (
                <form
                  onSubmit={handleSendVerification}
                  className="space-y-4 mt-4"
                >
                  <div className="space-y-2">
                    <Label htmlFor="reg-username" className="text-gray-300">
                      Username
                    </Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="reg-username"
                        name="username"
                        placeholder="Choose a username"
                        value={registerData.username}
                        onChange={handleRegisterChange}
                        className="pl-10 bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-gray-300">
                      Email
                    </Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="Enter your email"
                        value={registerData.email}
                        onChange={handleRegisterChange}
                        className="pl-10 bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reg-password" className="text-gray-300">
                      Password
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="reg-password"
                        name="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Create a password"
                        value={registerData.password}
                        onChange={handleRegisterChange}
                        className="pl-10 pr-10 bg-gray-700 border-gray-600 text-white"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 text-gray-400 hover:text-gray-300"
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password" className="text-gray-300">
                      Confirm Password
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="confirm-password"
                        name="confirmPassword"
                        type={showPassword ? "text" : "password"}
                        placeholder="Confirm your password"
                        value={registerData.confirmPassword}
                        onChange={handleRegisterChange}
                        className="pl-10 pr-10 bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 hover:from-blue-600 hover:via-indigo-600 hover:to-purple-600 button-hover"
                  >
                    Send Verification Code
                  </Button>
                </form>
              ) : (
                <form
                  onSubmit={handleVerifyAndRegister}
                  className="space-y-4 mt-4"
                >
                  <div className="space-y-2">
                    <Label
                      htmlFor="verification-code"
                      className="text-gray-300"
                    >
                      Verification Code
                    </Label>
                    <div className="relative">
                      <ShieldCheck className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="verification-code"
                        placeholder="Enter 6-digit code"
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value)}
                        className="pl-10 bg-gray-700 border-gray-600 text-white"
                        maxLength={6}
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 hover:from-blue-600 hover:via-indigo-600 hover:to-purple-600 button-hover"
                  >
                    Verify & Register
                  </Button>
                </form>
              )}

              <div className="mt-4 text-center">
                <p className="text-sm text-gray-400">
                  Already have an account?{" "}
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab("login");
                      setShowVerification(false);
                      setError("");
                      setSuccess("");
                    }}
                    className="text-indigo-400 hover:text-indigo-300 hover:underline"
                  >
                    Login here
                  </button>
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <p className="text-xs text-gray-400 text-center">
            By continuing, you agree to our Terms of Service and Privacy Policy.
          </p>
          <p className="text-xs text-gray-400 text-center">
            © 2023 ALDM Grade Tracking System. All rights reserved.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Auth;
