import { useState } from "react";
import { useTheme } from "./ThemeProvider";
import { Search, Mail, ArrowUpDown, LogOut, User } from "lucide-react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { sendGradeReport } from "./EmailService";

type Student = {
  id: string;
  name: string;
  parentEmail: string;
  lrn?: string;
  profilePicture?: string;
  grades: {
    q1: number | null;
    q2: number | null;
    q3: number | null;
    q4: number | null;
  };
  subjects: {
    name: string;
    grades: {
      q1: number | null;
      q2: number | null;
      q3: number | null;
      q4: number | null;
    };
  }[];
};

type GradeLevel = {
  level: string;
  students: Student[];
};

const getGradeLevels = (): GradeLevel[] => {
  // Get grade levels from localStorage (set by AdminDashboard)
  const savedGradeLevels = localStorage.getItem("gradeLevels");
  if (savedGradeLevels) {
    return JSON.parse(savedGradeLevels);
  }

  // If no grade levels exist yet, return empty structure
  const emptyGradeLevels: GradeLevel[] = [
    { level: "Grade 7", students: [] },
    { level: "Grade 8", students: [] },
    { level: "Grade 9", students: [] },
    { level: "Grade 10", students: [] },
  ];

  // Save empty structure to localStorage
  localStorage.setItem("gradeLevels", JSON.stringify(emptyGradeLevels));
  return emptyGradeLevels;
};

const getGradeStatus = (grade: number | null) => {
  if (grade === null) return { label: "N/A", variant: "outline" as const };
  if (grade >= 90) return { label: "Excellent", variant: "default" as const };
  if (grade >= 80) return { label: "Good", variant: "secondary" as const };
  if (grade >= 70) return { label: "Average", variant: "default" as const };
  return { label: "Needs Improvement", variant: "destructive" as const };
};

const calculateAverage = (grades: {
  q1: number | null;
  q2: number | null;
  q3: number | null;
  q4: number | null;
}) => {
  const validGrades = [grades.q1, grades.q2, grades.q3, grades.q4].filter(
    (g) => g !== null,
  ) as number[];
  if (validGrades.length === 0) return null;
  return Math.round(
    validGrades.reduce((sum, grade) => sum + grade, 0) / validGrades.length,
  );
};

interface StudentPortalProps {
  onLogout?: () => void;
}

const StudentPortal = ({ onLogout }: StudentPortalProps) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchType, setSearchType] = useState<"name" | "lrn">("name");
  const [activeTab, setActiveTab] = useState("overview");
  const gradeLevels = getGradeLevels();
  const [selectedGradeLevel, setSelectedGradeLevel] = useState(
    gradeLevels[0].level,
  );
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");

  const handleLogout = () => {
    localStorage.removeItem("currentUser");
    if (onLogout) {
      onLogout();
    }
    // Add a small delay before navigation to ensure state updates properly
    setTimeout(() => {
      navigate("/");
    }, 100);
  };

  // Filter out Clarence Jon Andaya specifically and then apply other filters
  const filteredStudents =
    gradeLevels
      .find((gl) => gl.level === selectedGradeLevel)
      ?.students.filter((student) => {
        // First filter out Clarence Jon Andaya
        if (student.name === "Clarence Jon Andaya") {
          return false;
        }

        // Then apply search filters
        if (searchType === "name") {
          return student.name.toLowerCase().includes(searchQuery.toLowerCase());
        } else {
          return student.lrn?.toLowerCase().includes(searchQuery.toLowerCase());
        }
      }) || [];

  const handleSendEmail = async (
    email: string,
    studentName: string,
    grades: any,
  ) => {
    console.log(`Sending email to ${email}`);

    try {
      await sendGradeReport(email, studentName, grades);

      // Show success message
      setSuccessMessage(`Email sent to: ${email}\nFrom: depedamba@gmail.com`);
      setShowSuccess(true);

      setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
    } catch (error) {
      console.error("Error sending email:", error);
    }
  };

  return (
    <div
      className={`flex flex-col w-full min-h-screen ${theme === "dark" ? "bg-gradient-to-b from-blue-950 to-indigo-950 text-white" : "bg-gradient-to-b from-blue-50 to-indigo-100 text-gray-900"} p-4 md:p-6 transition-colors duration-300`}
    >
      <style jsx>{`
        .card-hover {
          transition:
            transform 0.3s ease,
            box-shadow 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        .button-hover {
          transition: transform 0.2s ease;
        }
        .button-hover:active {
          transform: scale(0.95);
        }
        .fade-in {
          animation: fadeIn 0.5s ease-in;
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes slideInDown {
          from {
            opacity: 0;
            transform: translate(-50%, -20px);
          }
          to {
            opacity: 1;
            transform: translate(-50%, 0);
          }
        }
        .animate-slide-in-down {
          animation: slideInDown 0.5s ease forwards;
        }
      `}</style>

      {showSuccess && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded-md shadow-lg z-50 animate-slide-in-down">
          {successMessage}
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h1
          className={`text-2xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}
        >
          Student Portal
        </h1>
        <div className="flex space-x-2">
          <Button
            onClick={toggleTheme}
            variant="outline"
            className={`${theme === "dark" ? "border-blue-500 text-blue-400" : "border-blue-600 text-blue-600"} transition-all duration-300 button-hover`}
          >
            {theme === "dark" ? "☀️" : "🌙"}
          </Button>
          <Button
            variant="destructive"
            onClick={handleLogout}
            className="bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 button-hover transition-all duration-300"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="w-full md:w-1/3">
          <Card
            className={`${theme === "dark" ? "bg-blue-950 border-blue-500" : "bg-white border-blue-300"} border card-hover fade-in transition-colors duration-300`}
          >
            <CardHeader>
              <CardTitle
                className={theme === "dark" ? "text-white" : "text-gray-900"}
              >
                Grade Level
              </CardTitle>
              <CardDescription
                className={theme === "dark" ? "text-gray-400" : "text-gray-600"}
              >
                Select a grade level to view students
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {gradeLevels.map((gradeLevel) => (
                  <Button
                    key={gradeLevel.level}
                    variant={
                      selectedGradeLevel === gradeLevel.level
                        ? "default"
                        : "outline"
                    }
                    onClick={() => setSelectedGradeLevel(gradeLevel.level)}
                    className={
                      selectedGradeLevel === gradeLevel.level
                        ? "bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
                        : "border-indigo-500"
                    }
                  >
                    {gradeLevel.level}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="w-full md:w-2/3">
          <Card
            className={`${theme === "dark" ? "bg-blue-950 border-blue-500" : "bg-white border-blue-300"} border card-hover fade-in transition-colors duration-300`}
          >
            <CardHeader>
              <CardTitle
                className={theme === "dark" ? "text-white" : "text-gray-900"}
              >
                Student Search
              </CardTitle>
              <CardDescription
                className={theme === "dark" ? "text-gray-400" : "text-gray-600"}
              >
                Find students by name or LRN
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder={
                      searchType === "name"
                        ? "Search by name..."
                        : "Search by LRN..."
                    }
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`pl-8 ${theme === "dark" ? "bg-blue-900 border-blue-700 text-white" : "bg-blue-50 border-blue-200 text-gray-900"} transition-colors duration-300`}
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={searchType === "name" ? "default" : "outline"}
                    onClick={() => setSearchType("name")}
                    className={searchType === "name" ? "bg-blue-600" : ""}
                  >
                    <User className="h-4 w-4 mr-2" />
                    Name
                  </Button>
                  <Button
                    variant={searchType === "lrn" ? "default" : "outline"}
                    onClick={() => setSearchType("lrn")}
                    className={searchType === "lrn" ? "bg-blue-600" : ""}
                  >
                    <Search className="h-4 w-4 mr-2" />
                    LRN
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card
        className={`${theme === "dark" ? "bg-blue-950 border-blue-500" : "bg-white border-blue-300"} border flex-1 card-hover fade-in transition-colors duration-300 shadow-lg`}
      >
        <CardHeader>
          <CardTitle
            className={theme === "dark" ? "text-white" : "text-gray-900"}
          >
            Student Records - {selectedGradeLevel}
          </CardTitle>
          <CardDescription
            className={theme === "dark" ? "text-gray-400" : "text-gray-600"}
          >
            {filteredStudents.length} students found
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList
              className={`grid w-full grid-cols-2 ${theme === "dark" ? "bg-blue-900" : "bg-blue-100"} transition-colors duration-300`}
            >
              <TabsTrigger
                value="overview"
                className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger
                value="details"
                className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
              >
                Subject Details
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-4">
              <div
                className={`rounded-md border ${theme === "dark" ? "border-blue-700" : "border-blue-300"} overflow-hidden transition-colors duration-300`}
              >
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader
                      className={`${theme === "dark" ? "bg-blue-900" : "bg-blue-100"} transition-colors duration-300`}
                    >
                      <TableRow>
                        <TableHead
                          className={
                            theme === "dark" ? "text-white" : "text-gray-900"
                          }
                        >
                          Student
                        </TableHead>
                        <TableHead
                          className={
                            theme === "dark" ? "text-white" : "text-gray-900"
                          }
                        >
                          LRN
                        </TableHead>
                        <TableHead
                          className={
                            theme === "dark" ? "text-white" : "text-gray-900"
                          }
                        >
                          Q1
                        </TableHead>
                        <TableHead
                          className={
                            theme === "dark" ? "text-white" : "text-gray-900"
                          }
                        >
                          Q2
                        </TableHead>
                        <TableHead
                          className={
                            theme === "dark" ? "text-white" : "text-gray-900"
                          }
                        >
                          Q3
                        </TableHead>
                        <TableHead
                          className={
                            theme === "dark" ? "text-white" : "text-gray-900"
                          }
                        >
                          Q4
                        </TableHead>
                        <TableHead
                          className={
                            theme === "dark" ? "text-white" : "text-gray-900"
                          }
                        >
                          Average
                        </TableHead>
                        <TableHead
                          className={
                            theme === "dark" ? "text-white" : "text-gray-900"
                          }
                        >
                          Actions
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredStudents.length > 0 ? (
                        filteredStudents.map((student) => {
                          const average = calculateAverage(student.grades);
                          const averageStatus =
                            average !== null
                              ? getGradeStatus(average)
                              : { label: "N/A", variant: "outline" as const };

                          return (
                            <TableRow
                              key={student.id}
                              className={`${theme === "dark" ? "border-blue-800 hover:bg-blue-900" : "border-blue-200 hover:bg-blue-50"} transition-colors duration-300`}
                            >
                              <TableCell className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                                  <img
                                    src={
                                      student.profilePicture ||
                                      `https://api.dicebear.com/7.x/avataaars/svg?seed=${student.name}`
                                    }
                                    alt={student.name}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                                <span
                                  className={`font-medium ${theme === "dark" ? "text-white" : "text-gray-900"}`}
                                >
                                  {student.name}
                                </span>
                              </TableCell>
                              <TableCell
                                className={
                                  theme === "dark"
                                    ? "text-gray-300"
                                    : "text-gray-600"
                                }
                              >
                                {student.lrn || "N/A"}
                              </TableCell>
                              <TableCell>
                                {student.grades.q1 !== null ? (
                                  <Badge
                                    variant={
                                      getGradeStatus(student.grades.q1).variant
                                    }
                                  >
                                    {student.grades.q1}
                                  </Badge>
                                ) : (
                                  "N/A"
                                )}
                              </TableCell>
                              <TableCell>
                                {student.grades.q2 !== null ? (
                                  <Badge
                                    variant={
                                      getGradeStatus(student.grades.q2).variant
                                    }
                                  >
                                    {student.grades.q2}
                                  </Badge>
                                ) : (
                                  "N/A"
                                )}
                              </TableCell>
                              <TableCell>
                                {student.grades.q3 !== null ? (
                                  <Badge
                                    variant={
                                      getGradeStatus(student.grades.q3).variant
                                    }
                                  >
                                    {student.grades.q3}
                                  </Badge>
                                ) : (
                                  "N/A"
                                )}
                              </TableCell>
                              <TableCell>
                                {student.grades.q4 !== null ? (
                                  <Badge
                                    variant={
                                      getGradeStatus(student.grades.q4).variant
                                    }
                                  >
                                    {student.grades.q4}
                                  </Badge>
                                ) : (
                                  "N/A"
                                )}
                              </TableCell>
                              <TableCell>
                                {average !== null ? (
                                  <Badge
                                    variant={averageStatus.variant}
                                    className="font-bold"
                                  >
                                    {average}
                                  </Badge>
                                ) : (
                                  "N/A"
                                )}
                              </TableCell>
                              <TableCell>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() =>
                                    handleSendEmail(
                                      student.parentEmail,
                                      student.name,
                                      {
                                        ...student.grades,
                                        average: average,
                                      },
                                    )
                                  }
                                  className={`${theme === "dark" ? "hover:bg-blue-800" : "hover:bg-blue-100"} transition-colors duration-300`}
                                >
                                  <Mail className="h-4 w-4 mr-1" />
                                  Email
                                </Button>
                              </TableCell>
                            </TableRow>
                          );
                        })
                      ) : (
                        <TableRow>
                          <TableCell
                            colSpan={8}
                            className="h-24 text-center text-gray-400"
                          >
                            No students found.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="details" className="mt-4">
              {filteredStudents.length > 0 ? (
                filteredStudents.map((student) => (
                  <Card
                    key={student.id}
                    className={`mb-4 ${theme === "dark" ? "bg-blue-900 border-blue-700" : "bg-white border-blue-300"} card-hover fade-in transition-colors duration-300`}
                  >
                    <CardHeader>
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0">
                            <img
                              src={
                                student.profilePicture ||
                                `https://api.dicebear.com/7.x/avataaars/svg?seed=${student.name}`
                              }
                              alt={student.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div>
                            <CardTitle
                              className={
                                theme === "dark"
                                  ? "text-white"
                                  : "text-gray-900"
                              }
                            >
                              {student.name}
                            </CardTitle>
                            <CardDescription
                              className={
                                theme === "dark"
                                  ? "text-gray-400"
                                  : "text-gray-600"
                              }
                            >
                              LRN: {student.lrn || "N/A"}
                            </CardDescription>
                          </div>
                        </div>
                        <div>
                          <Badge variant="outline" className="text-gray-300">
                            {student.id}
                          </Badge>
                        </div>
                      </div>
                      <CardDescription
                        className={
                          theme === "dark" ? "text-gray-400" : "text-gray-600"
                        }
                      >
                        Parent Email: {student.parentEmail}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Tabs defaultValue="q1" className="w-full">
                        <TabsList
                          className={`grid w-full grid-cols-2 sm:grid-cols-5 ${theme === "dark" ? "bg-blue-900" : "bg-blue-100"} mb-4 transition-colors duration-300`}
                        >
                          <TabsTrigger
                            value="q1"
                            className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
                          >
                            Q1
                          </TabsTrigger>
                          <TabsTrigger
                            value="q2"
                            className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
                          >
                            Q2
                          </TabsTrigger>
                          <TabsTrigger
                            value="q3"
                            className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
                          >
                            Q3
                          </TabsTrigger>
                          <TabsTrigger
                            value="q4"
                            className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
                          >
                            Q4
                          </TabsTrigger>
                          <TabsTrigger
                            value="all"
                            className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
                          >
                            All
                          </TabsTrigger>
                        </TabsList>

                        {/* 1st Quarter Tab */}
                        <TabsContent value="q1">
                          <div
                            className={`rounded-md border ${theme === "dark" ? "border-blue-700" : "border-blue-300"} overflow-hidden transition-colors duration-300`}
                          >
                            <div className="overflow-x-auto">
                              <Table>
                                <TableHeader
                                  className={`${theme === "dark" ? "bg-blue-900" : "bg-blue-100"} transition-colors duration-300`}
                                >
                                  <TableRow>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      <div className="flex items-center">
                                        Subject
                                        <ArrowUpDown className="ml-2 h-4 w-4" />
                                      </div>
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Grade
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Status
                                    </TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {student.subjects.map((subject) => {
                                    const gradeStatus = getGradeStatus(
                                      subject.grades.q1,
                                    );
                                    return (
                                      <TableRow
                                        key={subject.name}
                                        className={`${theme === "dark" ? "border-blue-700" : "border-blue-200"} transition-colors duration-300`}
                                      >
                                        <TableCell
                                          className={`font-medium ${theme === "dark" ? "text-white" : "text-gray-900"}`}
                                        >
                                          {subject.name}
                                        </TableCell>
                                        <TableCell>
                                          {subject.grades.q1 !== null ? (
                                            <Badge
                                              variant={gradeStatus.variant}
                                            >
                                              {subject.grades.q1}
                                            </Badge>
                                          ) : (
                                            "N/A"
                                          )}
                                        </TableCell>
                                        <TableCell
                                          className={
                                            theme === "dark"
                                              ? "text-gray-300"
                                              : "text-gray-600"
                                          }
                                        >
                                          {gradeStatus.label}
                                        </TableCell>
                                      </TableRow>
                                    );
                                  })}
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                        </TabsContent>

                        {/* 2nd Quarter Tab */}
                        <TabsContent value="q2">
                          <div
                            className={`rounded-md border ${theme === "dark" ? "border-blue-700" : "border-blue-300"} overflow-hidden transition-colors duration-300`}
                          >
                            <div className="overflow-x-auto">
                              <Table>
                                <TableHeader
                                  className={`${theme === "dark" ? "bg-blue-900" : "bg-blue-100"} transition-colors duration-300`}
                                >
                                  <TableRow>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      <div className="flex items-center">
                                        Subject
                                        <ArrowUpDown className="ml-2 h-4 w-4" />
                                      </div>
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Grade
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Status
                                    </TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {student.subjects.map((subject) => {
                                    const gradeStatus = getGradeStatus(
                                      subject.grades.q2,
                                    );
                                    return (
                                      <TableRow
                                        key={subject.name}
                                        className={`${theme === "dark" ? "border-blue-700" : "border-blue-200"} transition-colors duration-300`}
                                      >
                                        <TableCell
                                          className={`font-medium ${theme === "dark" ? "text-white" : "text-gray-900"}`}
                                        >
                                          {subject.name}
                                        </TableCell>
                                        <TableCell>
                                          {subject.grades.q2 !== null ? (
                                            <Badge
                                              variant={gradeStatus.variant}
                                            >
                                              {subject.grades.q2}
                                            </Badge>
                                          ) : (
                                            "N/A"
                                          )}
                                        </TableCell>
                                        <TableCell
                                          className={
                                            theme === "dark"
                                              ? "text-gray-300"
                                              : "text-gray-600"
                                          }
                                        >
                                          {gradeStatus.label}
                                        </TableCell>
                                      </TableRow>
                                    );
                                  })}
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                        </TabsContent>

                        {/* 3rd Quarter Tab */}
                        <TabsContent value="q3">
                          <div
                            className={`rounded-md border ${theme === "dark" ? "border-blue-700" : "border-blue-300"} overflow-hidden transition-colors duration-300`}
                          >
                            <div className="overflow-x-auto">
                              <Table>
                                <TableHeader
                                  className={`${theme === "dark" ? "bg-blue-900" : "bg-blue-100"} transition-colors duration-300`}
                                >
                                  <TableRow>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      <div className="flex items-center">
                                        Subject
                                        <ArrowUpDown className="ml-2 h-4 w-4" />
                                      </div>
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Grade
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Status
                                    </TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {student.subjects.map((subject) => {
                                    const gradeStatus = getGradeStatus(
                                      subject.grades.q3,
                                    );
                                    return (
                                      <TableRow
                                        key={subject.name}
                                        className={`${theme === "dark" ? "border-blue-700" : "border-blue-200"} transition-colors duration-300`}
                                      >
                                        <TableCell
                                          className={`font-medium ${theme === "dark" ? "text-white" : "text-gray-900"}`}
                                        >
                                          {subject.name}
                                        </TableCell>
                                        <TableCell>
                                          {subject.grades.q3 !== null ? (
                                            <Badge
                                              variant={gradeStatus.variant}
                                            >
                                              {subject.grades.q3}
                                            </Badge>
                                          ) : (
                                            "N/A"
                                          )}
                                        </TableCell>
                                        <TableCell
                                          className={
                                            theme === "dark"
                                              ? "text-gray-300"
                                              : "text-gray-600"
                                          }
                                        >
                                          {gradeStatus.label}
                                        </TableCell>
                                      </TableRow>
                                    );
                                  })}
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                        </TabsContent>

                        {/* 4th Quarter Tab */}
                        <TabsContent value="q4">
                          <div
                            className={`rounded-md border ${theme === "dark" ? "border-blue-700" : "border-blue-300"} overflow-hidden transition-colors duration-300`}
                          >
                            <div className="overflow-x-auto">
                              <Table>
                                <TableHeader
                                  className={`${theme === "dark" ? "bg-blue-900" : "bg-blue-100"} transition-colors duration-300`}
                                >
                                  <TableRow>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      <div className="flex items-center">
                                        Subject
                                        <ArrowUpDown className="ml-2 h-4 w-4" />
                                      </div>
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Grade
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Status
                                    </TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {student.subjects.map((subject) => {
                                    const gradeStatus = getGradeStatus(
                                      subject.grades.q4,
                                    );
                                    return (
                                      <TableRow
                                        key={subject.name}
                                        className={`${theme === "dark" ? "border-blue-700" : "border-blue-200"} transition-colors duration-300`}
                                      >
                                        <TableCell
                                          className={`font-medium ${theme === "dark" ? "text-white" : "text-gray-900"}`}
                                        >
                                          {subject.name}
                                        </TableCell>
                                        <TableCell>
                                          {subject.grades.q4 !== null ? (
                                            <Badge
                                              variant={gradeStatus.variant}
                                            >
                                              {subject.grades.q4}
                                            </Badge>
                                          ) : (
                                            "N/A"
                                          )}
                                        </TableCell>
                                        <TableCell
                                          className={
                                            theme === "dark"
                                              ? "text-gray-300"
                                              : "text-gray-600"
                                          }
                                        >
                                          {gradeStatus.label}
                                        </TableCell>
                                      </TableRow>
                                    );
                                  })}
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                        </TabsContent>

                        {/* All Quarters Tab */}
                        <TabsContent value="all">
                          <div
                            className={`rounded-md border ${theme === "dark" ? "border-blue-700" : "border-blue-300"} overflow-hidden transition-colors duration-300`}
                          >
                            <div className="overflow-x-auto">
                              <Table>
                                <TableHeader
                                  className={`${theme === "dark" ? "bg-blue-900" : "bg-blue-100"} transition-colors duration-300`}
                                >
                                  <TableRow>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      <div className="flex items-center">
                                        Subject
                                        <ArrowUpDown className="ml-2 h-4 w-4" />
                                      </div>
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Q1
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Q2
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Q3
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Q4
                                    </TableHead>
                                    <TableHead
                                      className={
                                        theme === "dark"
                                          ? "text-white"
                                          : "text-gray-900"
                                      }
                                    >
                                      Average
                                    </TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {student.subjects.map((subject) => {
                                    const average = calculateAverage(
                                      subject.grades,
                                    );
                                    const averageStatus =
                                      average !== null
                                        ? getGradeStatus(average)
                                        : {
                                            label: "N/A",
                                            variant: "outline" as const,
                                          };

                                    return (
                                      <TableRow
                                        key={subject.name}
                                        className={`${theme === "dark" ? "border-blue-700" : "border-blue-200"} transition-colors duration-300`}
                                      >
                                        <TableCell
                                          className={`font-medium ${theme === "dark" ? "text-white" : "text-gray-900"}`}
                                        >
                                          {subject.name}
                                        </TableCell>
                                        <TableCell>
                                          {subject.grades.q1 !== null ? (
                                            <Badge
                                              variant={
                                                getGradeStatus(
                                                  subject.grades.q1,
                                                ).variant
                                              }
                                            >
                                              {subject.grades.q1}
                                            </Badge>
                                          ) : (
                                            "N/A"
                                          )}
                                        </TableCell>
                                        <TableCell>
                                          {subject.grades.q2 !== null ? (
                                            <Badge
                                              variant={
                                                getGradeStatus(
                                                  subject.grades.q2,
                                                ).variant
                                              }
                                            >
                                              {subject.grades.q2}
                                            </Badge>
                                          ) : (
                                            "N/A"
                                          )}
                                        </TableCell>
                                        <TableCell>
                                          {subject.grades.q3 !== null ? (
                                            <Badge
                                              variant={
                                                getGradeStatus(
                                                  subject.grades.q3,
                                                ).variant
                                              }
                                            >
                                              {subject.grades.q3}
                                            </Badge>
                                          ) : (
                                            "N/A"
                                          )}
                                        </TableCell>
                                        <TableCell>
                                          {subject.grades.q4 !== null ? (
                                            <Badge
                                              variant={
                                                getGradeStatus(
                                                  subject.grades.q4,
                                                ).variant
                                              }
                                            >
                                              {subject.grades.q4}
                                            </Badge>
                                          ) : (
                                            "N/A"
                                          )}
                                        </TableCell>
                                        <TableCell>
                                          {average !== null ? (
                                            <Badge
                                              variant={averageStatus.variant}
                                              className="font-bold"
                                            >
                                              {average}
                                            </Badge>
                                          ) : (
                                            "N/A"
                                          )}
                                        </TableCell>
                                      </TableRow>
                                    );
                                  })}
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center p-8 text-gray-400">
                  No students found. Try adjusting your search.
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default StudentPortal;
