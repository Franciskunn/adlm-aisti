import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useTheme } from "./ThemeProvider";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import StudentTable from "./StudentTable";
import GradeLevelDashboard from "./GradeLevelDashboard";
import MessagingSystem from "./MessagingSystem";
import {
  Search,
  LogOut,
  Users,
  FileText,
  Mail,
  GraduationCap,
  MessageSquare,
} from "lucide-react";

interface Subject {
  name: string;
  type:
    | "Mathematics"
    | "Science"
    | "English"
    | "Filipino"
    | "MAPEH"
    | "Araling Panlipunan"
    | "ESP"
    | "TLE";
  q1: number;
  q2: number;
  q3: number;
  q4: number;
  average: number;
}

interface Student {
  id: string;
  name: string;
  parentEmail: string;
  q1: number;
  q2: number;
  q3: number;
  q4: number;
  average: number;
  gradeLevel: 7 | 8 | 9 | 10;
  subjects?: Subject[];
}

interface AdminDashboardProps {
  onLogout?: () => void;
}

const AdminDashboard = ({ onLogout }: AdminDashboardProps) => {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const [currentUser, setCurrentUser] = useState<{
    username: string;
    role: string;
  } | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGradeLevel, setSelectedGradeLevel] = useState<string>("all");
  const [students, setStudents] = useState<Student[]>([]);
  const [showAddSuccess, setShowAddSuccess] = useState(false);
  const [showEditSuccess, setShowEditSuccess] = useState(false);
  const [showDeleteSuccess, setShowDeleteSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");

  // Check if user is logged in and is admin
  useEffect(() => {
    const userStr = localStorage.getItem("currentUser");
    if (!userStr) {
      navigate("/");
      return;
    }

    const user = JSON.parse(userStr);
    if (user.role !== "admin") {
      navigate("/student");
      return;
    }

    setCurrentUser(user);

    // Load students from localStorage
    const storedStudents = localStorage.getItem("students");
    if (storedStudents) {
      setStudents(JSON.parse(storedStudents));
    } else {
      // Initialize with empty array if none exists
      const emptyStudents = [];
      localStorage.setItem("students", JSON.stringify(emptyStudents));
      setStudents(emptyStudents);
    }

    // Initialize grade levels in localStorage if they don't exist
    const gradeLevels = localStorage.getItem("gradeLevels");
    if (!gradeLevels) {
      const initialGradeLevels = [
        { level: "Grade 7", students: [] },
        { level: "Grade 8", students: [] },
        { level: "Grade 9", students: [] },
        { level: "Grade 10", students: [] },
      ];
      localStorage.setItem("gradeLevels", JSON.stringify(initialGradeLevels));
    }
  }, [navigate]);

  // Filter students based on search term and grade level
  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.parentEmail.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGradeLevel =
      selectedGradeLevel === "all" ||
      student.gradeLevel.toString() === selectedGradeLevel;

    return matchesSearch && matchesGradeLevel;
  });

  const handleLogout = () => {
    localStorage.removeItem("currentUser");
    if (onLogout) {
      onLogout();
    }
    navigate("/");
  };

  const handleSendEmail = (emails: string[]) => {
    alert(`Email would be sent to: ${emails.join(", ")}`);
    // In a real implementation, this would integrate with EmailJS or similar
  };

  // Helper function to determine subject type
  function determineSubjectType(subjectName: string): Subject["type"] {
    const name = subjectName.toLowerCase();
    if (name.includes("math")) return "Mathematics";
    if (name.includes("science")) return "Science";
    if (name.includes("english")) return "English";
    if (name.includes("filipino")) return "Filipino";
    if (name.includes("mapeh")) return "MAPEH";
    if (name.includes("araling") || name.includes("ap"))
      return "Araling Panlipunan";
    if (name.includes("esp")) return "ESP";
    if (name.includes("tle")) return "TLE";

    // Default to Mathematics if no match
    return "Mathematics";
  }

  const handleAddStudent = () => {
    // Create a modal-like dialog for adding a new student
    const dialog = document.createElement("div");
    dialog.style.position = "fixed";
    dialog.style.top = "0";
    dialog.style.left = "0";
    dialog.style.width = "100%";
    dialog.style.height = "100%";
    dialog.style.backgroundColor = "rgba(0, 0, 0, 0.8)";
    dialog.style.display = "flex";
    dialog.style.justifyContent = "center";
    dialog.style.alignItems = "center";
    dialog.style.zIndex = "1000";
    dialog.style.transition = "all 0.3s ease-in-out";
    dialog.style.opacity = "0";

    // Fade in animation
    setTimeout(() => {
      dialog.style.opacity = "1";
    }, 10);

    // Create the form container
    const formContainer = document.createElement("div");
    formContainer.style.backgroundColor = "#000000";
    formContainer.style.padding = "2rem";
    formContainer.style.borderRadius = "0.5rem";
    formContainer.style.width = "90%";
    formContainer.style.maxWidth = "700px";
    formContainer.style.maxHeight = "85vh";
    formContainer.style.overflowY = "auto";
    formContainer.style.border = "2px solid transparent";
    formContainer.style.borderImageSlice = "1";
    formContainer.style.borderImageSource =
      "linear-gradient(to right, #3b82f6, #6366f1, #8b5cf6)";
    formContainer.style.boxShadow = "0 0 20px rgba(239, 68, 68, 0.3)";

    // Create the form content
    formContainer.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; border-bottom: 1px solid #374151; padding-bottom: 1rem;">
        <h2 style="font-size: 1.5rem; font-weight: bold; background: linear-gradient(to right, #a855f7, #ec4899, #ef4444); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Add New Student</h2>
        <button id="close-btn" style="background: none; border: none; color: #9ca3af; font-size: 1.5rem; cursor: pointer;">×</button>
      </div>
      
      <div style="margin-bottom: 1.5rem;">
        <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Student Name</label>
        <input id="student-name" type="text" placeholder="Enter student name" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
      </div>
      
      <div style="margin-bottom: 1.5rem;">
        <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Parent Email</label>
        <input id="parent-email" type="email" placeholder="Enter parent email" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
      </div>

      <div style="margin-bottom: 1.5rem;">
        <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Grade Level</label>
        <select id="grade-level" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          <option value="7">Grade 7</option>
          <option value="8">Grade 8</option>
          <option value="9">Grade 9</option>
          <option value="10">Grade 10</option>
        </select>
      </div>
      
      <div style="background: linear-gradient(to right, rgba(168, 85, 247, 0.1), rgba(236, 72, 153, 0.1), rgba(239, 68, 68, 0.1)); padding: 1rem; border-radius: 0.375rem; margin-bottom: 1.5rem;">
        <h3 style="font-size: 1.25rem; font-weight: bold; margin-bottom: 1rem; color: #e5e7eb;">Overall Grades</h3>
        
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1 Grade</label>
            <input id="q1-grade" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2 Grade</label>
            <input id="q2-grade" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3 Grade</label>
            <input id="q3-grade" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4 Grade</label>
            <input id="q4-grade" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
        </div>
      </div>
      
      <div style="background: linear-gradient(to right, rgba(168, 85, 247, 0.1), rgba(236, 72, 153, 0.1), rgba(239, 68, 68, 0.1)); padding: 1rem; border-radius: 0.375rem; margin-bottom: 1.5rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
          <h3 style="font-size: 1.25rem; font-weight: bold; color: #e5e7eb;">Subject Grades</h3>
        </div>
        
        <div id="subjects-container" style="max-height: 400px; overflow-y: auto; padding-right: 0.5rem;">
          <!-- English -->
          <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #ef4444;">
            <div style="margin-bottom: 1rem;">
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">English</label>
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
                <input class="subject-q1" data-subject="English" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
                <input class="subject-q2" data-subject="English" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
                <input class="subject-q3" data-subject="English" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
                <input class="subject-q4" data-subject="English" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
            </div>
          </div>
          
          <!-- ESP -->
          <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #3b82f6;">
            <div style="margin-bottom: 1rem;">
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">ESP</label>
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
                <input class="subject-q1" data-subject="ESP" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
                <input class="subject-q2" data-subject="ESP" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
                <input class="subject-q3" data-subject="ESP" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
                <input class="subject-q4" data-subject="ESP" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
            </div>
          </div>
          
          <!-- Filipino -->
          <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #10b981;">
            <div style="margin-bottom: 1rem;">
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Filipino</label>
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
                <input class="subject-q1" data-subject="Filipino" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
                <input class="subject-q2" data-subject="Filipino" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
                <input class="subject-q3" data-subject="Filipino" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
                <input class="subject-q4" data-subject="Filipino" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
            </div>
          </div>
          
          <!-- MAPEH -->
          <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #f59e0b;">
            <div style="margin-bottom: 1rem;">
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">MAPEH</label>
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
                <input class="subject-q1" data-subject="MAPEH" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
                <input class="subject-q2" data-subject="MAPEH" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
                <input class="subject-q3" data-subject="MAPEH" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
                <input class="subject-q4" data-subject="MAPEH" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
            </div>
          </div>
          
          <!-- Mathematics -->
          <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #8b5cf6;">
            <div style="margin-bottom: 1rem;">
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Mathematics</label>
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
                <input class="subject-q1" data-subject="Mathematics" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
                <input class="subject-q2" data-subject="Mathematics" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
                <input class="subject-q3" data-subject="Mathematics" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
                <input class="subject-q4" data-subject="Mathematics" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
            </div>
          </div>
          
          <!-- Science -->
          <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #ec4899;">
            <div style="margin-bottom: 1rem;">
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Science</label>
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
                <input class="subject-q1" data-subject="Science" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
                <input class="subject-q2" data-subject="Science" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
                <input class="subject-q3" data-subject="Science" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
                <input class="subject-q4" data-subject="Science" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
            </div>
          </div>
          
          <!-- TLE -->
          <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #06b6d4;">
            <div style="margin-bottom: 1rem;">
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">TLE</label>
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
                <input class="subject-q1" data-subject="TLE" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
                <input class="subject-q2" data-subject="TLE" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
                <input class="subject-q3" data-subject="TLE" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
                <input class="subject-q4" data-subject="TLE" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
            </div>
          </div>
          
          <!-- Araling Panlipunan (AP) -->
          <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #d97706;">
            <div style="margin-bottom: 1rem;">
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Araling Panlipunan (AP)</label>
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
                <input class="subject-q1" data-subject="Araling Panlipunan" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
                <input class="subject-q2" data-subject="Araling Panlipunan" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
                <input class="subject-q3" data-subject="Araling Panlipunan" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
                <input class="subject-q4" data-subject="Araling Panlipunan" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 2rem;">
        <button id="cancel-btn" style="padding: 0.75rem 1.5rem; background-color: transparent; border: 1px solid #ef4444; border-radius: 0.375rem; color: #ef4444; cursor: pointer; font-weight: 500;">Cancel</button>
        <button id="save-btn" style="padding: 0.75rem 1.5rem; background: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); border: none; border-radius: 0.375rem; color: white; cursor: pointer; font-weight: 500;">Add Student</button>
      </div>
    `;

    dialog.appendChild(formContainer);
    document.body.appendChild(dialog);

    // Add event listeners
    const addSubjectBtn = document.getElementById("add-subject-btn");
    const subjectsContainer = document.getElementById("subjects-container");
    const cancelBtn = document.getElementById("cancel-btn");
    const saveBtn = document.getElementById("save-btn");
    const closeBtn = document.getElementById("close-btn");

    // Add subject button
    addSubjectBtn?.addEventListener("click", () => {
      const newSubjectElement = document.createElement("div");
      newSubjectElement.className = "subject-row";
      newSubjectElement.style.backgroundColor = "#1f2937";
      newSubjectElement.style.borderRadius = "0.375rem";
      newSubjectElement.style.padding = "1.25rem";
      newSubjectElement.style.marginBottom = "1rem";
      newSubjectElement.style.borderLeft = "3px solid #ef4444";

      newSubjectElement.innerHTML = `
        <div style="margin-bottom: 1rem;">
          <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Subject Name</label>
          <input class="subject-name" type="text" placeholder="e.g. Math" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
        </div>
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
            <input class="subject-q1" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
            <input class="subject-q2" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
            <input class="subject-q3" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
            <input class="subject-q4" type="number" min="0" max="100" value="75" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
        </div>
        <div style="display: flex; justify-content: flex-end; margin-top: 1rem;">
          <button class="remove-subject-btn" style="padding: 0.5rem 1rem; background-color: rgba(220, 38, 38, 0.2); border: 1px solid #dc2626; border-radius: 0.375rem; color: #ef4444; cursor: pointer; font-weight: 500;">Remove Subject</button>
        </div>
      `;

      subjectsContainer?.appendChild(newSubjectElement);

      // Add event listener to the new remove button
      const removeBtn = newSubjectElement.querySelector(".remove-subject-btn");
      removeBtn?.addEventListener("click", () => {
        newSubjectElement.remove();
      });
    });

    // Add event listeners to existing remove buttons
    document.querySelectorAll(".remove-subject-btn").forEach((button) => {
      button.addEventListener("click", (e) => {
        const subjectRow = (e.target as HTMLElement).closest(".subject-row");
        if (subjectRow) {
          subjectRow.remove();
        }
      });
    });

    // Cancel button
    cancelBtn?.addEventListener("click", () => {
      document.body.removeChild(dialog);
    });

    // Close button
    closeBtn?.addEventListener("click", () => {
      document.body.removeChild(dialog);
    });

    // Save button
    saveBtn?.addEventListener("click", () => {
      const nameInput = document.getElementById(
        "student-name",
      ) as HTMLInputElement;
      const emailInput = document.getElementById(
        "parent-email",
      ) as HTMLInputElement;
      const gradeLevelSelect = document.getElementById(
        "grade-level",
      ) as HTMLSelectElement;
      const q1Input = document.getElementById("q1-grade") as HTMLInputElement;
      const q2Input = document.getElementById("q2-grade") as HTMLInputElement;
      const q3Input = document.getElementById("q3-grade") as HTMLInputElement;
      const q4Input = document.getElementById("q4-grade") as HTMLInputElement;

      const name = nameInput.value;
      const parentEmail = emailInput.value;
      const gradeLevel = parseInt(gradeLevelSelect.value) as 7 | 8 | 9 | 10;
      const q1 = parseInt(q1Input.value);
      const q2 = parseInt(q2Input.value);
      const q3 = parseInt(q3Input.value);
      const q4 = parseInt(q4Input.value);

      if (!name || !parentEmail) {
        alert("Student name and parent email are required!");
        return;
      }

      // Collect subject data
      const subjects: Subject[] = [];
      document.querySelectorAll(".subject-row").forEach((row) => {
        const q1Input = row.querySelector(".subject-q1") as HTMLInputElement;
        const q2Input = row.querySelector(".subject-q2") as HTMLInputElement;
        const q3Input = row.querySelector(".subject-q3") as HTMLInputElement;
        const q4Input = row.querySelector(".subject-q4") as HTMLInputElement;

        // Get subject name from data attribute
        const subjectName = q1Input.getAttribute("data-subject") || "";

        if (subjectName) {
          const q1 = parseInt(q1Input.value) || 0;
          const q2 = parseInt(q2Input.value) || 0;
          const q3 = parseInt(q3Input.value) || 0;
          const q4 = parseInt(q4Input.value) || 0;
          const average = (q1 + q2 + q3 + q4) / 4;

          subjects.push({
            name: subjectName,
            type: determineSubjectType(subjectName),
            q1,
            q2,
            q3,
            q4,
            average,
          });
        }
      });

      const average = (q1 + q2 + q3 + q4) / 4;

      // Generate a unique ID
      const id = `S${Date.now().toString().slice(-6)}`;

      // Create the new student object
      const newStudent: Student = {
        id,
        name,
        parentEmail,
        q1,
        q2,
        q3,
        q4,
        average,
        gradeLevel,
        subjects,
      };

      // Add the new student to the students array
      const updatedStudents = [...students, newStudent];
      setStudents(updatedStudents);

      // Save to localStorage
      localStorage.setItem("students", JSON.stringify(updatedStudents));

      // Also save to localStorage for StudentPortal to access
      const gradeLevels = JSON.parse(
        localStorage.getItem("gradeLevels") || "[]",
      );
      let gradeLevel7 = gradeLevels.find((gl: any) => gl.level === "Grade 7");
      let gradeLevel8 = gradeLevels.find((gl: any) => gl.level === "Grade 8");
      let gradeLevel9 = gradeLevels.find((gl: any) => gl.level === "Grade 9");
      let gradeLevel10 = gradeLevels.find((gl: any) => gl.level === "Grade 10");

      if (!gradeLevel7) {
        gradeLevel7 = { level: "Grade 7", students: [] };
        gradeLevels.push(gradeLevel7);
      }
      if (!gradeLevel8) {
        gradeLevel8 = { level: "Grade 8", students: [] };
        gradeLevels.push(gradeLevel8);
      }
      if (!gradeLevel9) {
        gradeLevel9 = { level: "Grade 9", students: [] };
        gradeLevels.push(gradeLevel9);
      }
      if (!gradeLevel10) {
        gradeLevel10 = { level: "Grade 10", students: [] };
        gradeLevels.push(gradeLevel10);
      }

      // Convert the admin student format to student portal format
      const studentPortalFormat = {
        id,
        name,
        parentEmail,
        grades: {
          q1,
          q2,
          q3,
          q4,
        },
        subjects: subjects.map((subject) => ({
          name: subject.name,
          grades: {
            q1: subject.q1,
            q2: subject.q2,
            q3: subject.q3,
            q4: subject.q4,
          },
        })),
      };

      // Add to the appropriate grade level
      switch (gradeLevel) {
        case 7:
          gradeLevel7.students.push(studentPortalFormat);
          break;
        case 8:
          gradeLevel8.students.push(studentPortalFormat);
          break;
        case 9:
          gradeLevel9.students.push(studentPortalFormat);
          break;
        case 10:
          gradeLevel10.students.push(studentPortalFormat);
          break;
      }

      localStorage.setItem("gradeLevels", JSON.stringify(gradeLevels));

      // Show success message with animation
      const successMessage = document.createElement("div");
      successMessage.style.position = "fixed";
      successMessage.style.top = "20px";
      successMessage.style.left = "50%";
      successMessage.style.transform = "translateX(-50%)";
      successMessage.style.backgroundColor = "rgba(16, 185, 129, 0.9)";
      successMessage.style.color = "white";
      successMessage.style.padding = "12px 24px";
      successMessage.style.borderRadius = "4px";
      successMessage.style.zIndex = "2000";
      successMessage.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
      successMessage.style.transition = "all 0.3s ease";
      successMessage.style.opacity = "0";
      successMessage.style.transform = "translateX(-50%) translateY(-20px)";
      successMessage.textContent = `Student ${name} added successfully!`;

      document.body.appendChild(successMessage);

      setTimeout(() => {
        successMessage.style.opacity = "1";
        successMessage.style.transform = "translateX(-50%) translateY(0)";
      }, 10);

      setTimeout(() => {
        successMessage.style.opacity = "0";
        successMessage.style.transform = "translateX(-50%) translateY(-20px)";
        setTimeout(() => document.body.removeChild(successMessage), 300);
      }, 3000);

      // Fade out dialog
      dialog.style.opacity = "0";
      setTimeout(() => document.body.removeChild(dialog), 300);
    });
  };

  const handleEditStudent = (student: Student) => {
    // Create a modal-like dialog for editing student information
    const dialog = document.createElement("div");
    dialog.style.position = "fixed";
    dialog.style.top = "0";
    dialog.style.left = "0";
    dialog.style.width = "100%";
    dialog.style.height = "100%";
    dialog.style.backgroundColor = "rgba(0, 0, 0, 0.8)";
    dialog.style.display = "flex";
    dialog.style.justifyContent = "center";
    dialog.style.alignItems = "center";
    dialog.style.zIndex = "1000";
    dialog.style.transition = "all 0.3s ease-in-out";
    dialog.style.opacity = "0";

    // Fade in animation
    setTimeout(() => {
      dialog.style.opacity = "1";
    }, 10);

    // Create the form container
    const formContainer = document.createElement("div");
    formContainer.style.backgroundColor = "#000000";
    formContainer.style.padding = "2rem";
    formContainer.style.borderRadius = "0.5rem";
    formContainer.style.width = "90%";
    formContainer.style.maxWidth = "700px";
    formContainer.style.maxHeight = "85vh";
    formContainer.style.overflowY = "auto";
    formContainer.style.border = "2px solid transparent";
    formContainer.style.borderImageSlice = "1";
    formContainer.style.borderImageSource =
      "linear-gradient(to right, #3b82f6, #6366f1, #8b5cf6)";
    formContainer.style.boxShadow = "0 0 20px rgba(239, 68, 68, 0.3)";

    // Create the form content
    formContainer.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; border-bottom: 1px solid #374151; padding-bottom: 1rem;">
        <h2 style="font-size: 1.5rem; font-weight: bold; background: linear-gradient(to right, #a855f7, #ec4899, #ef4444); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Edit Student Information</h2>
        <button id="close-btn" style="background: none; border: none; color: #9ca3af; font-size: 1.5rem; cursor: pointer;">×</button>
      </div>
      
      <div style="margin-bottom: 1.5rem;">
        <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Student Name</label>
        <input id="student-name" type="text" value="${student.name}" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
      </div>
      
      <div style="margin-bottom: 1.5rem;">
        <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Parent Email</label>
        <input id="parent-email" type="email" value="${student.parentEmail}" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
      </div>
      
      <div style="background: linear-gradient(to right, rgba(168, 85, 247, 0.1), rgba(236, 72, 153, 0.1), rgba(239, 68, 68, 0.1)); padding: 1rem; border-radius: 0.375rem; margin-bottom: 1.5rem;">
        <h3 style="font-size: 1.25rem; font-weight: bold; margin-bottom: 1rem; color: #e5e7eb;">Overall Grades</h3>
        
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1 Grade</label>
            <input id="q1-grade" type="number" min="0" max="100" value="${student.q1}" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2 Grade</label>
            <input id="q2-grade" type="number" min="0" max="100" value="${student.q2}" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3 Grade</label>
            <input id="q3-grade" type="number" min="0" max="100" value="${student.q3}" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4 Grade</label>
            <input id="q4-grade" type="number" min="0" max="100" value="${student.q4}" style="width: 100%; padding: 0.75rem; background-color: #1f2937; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
        </div>
      </div>
      
      <div style="background: linear-gradient(to right, rgba(168, 85, 247, 0.1), rgba(236, 72, 153, 0.1), rgba(239, 68, 68, 0.1)); padding: 1rem; border-radius: 0.375rem; margin-bottom: 1.5rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
          <h3 style="font-size: 1.25rem; font-weight: bold; color: #e5e7eb;">Subject Grades</h3>
          <button id="add-subject-btn" style="padding: 0.5rem 1rem; background: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); border: none; border-radius: 0.375rem; color: white; cursor: pointer; font-weight: 500;">+ Add Subject</button>
        </div>
        
        <div id="subjects-container" style="max-height: 400px; overflow-y: auto; padding-right: 0.5rem;">
          ${generateSubjectInputs(student.subjects || [])}
        </div>
      </div>
      
      <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 2rem;">
        <button id="cancel-btn" style="padding: 0.75rem 1.5rem; background-color: transparent; border: 1px solid #ef4444; border-radius: 0.375rem; color: #ef4444; cursor: pointer; font-weight: 500;">Cancel</button>
        <button id="save-btn" style="padding: 0.75rem 1.5rem; background: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); border: none; border-radius: 0.375rem; color: white; cursor: pointer; font-weight: 500;">Save Changes</button>
      </div>
    `;

    dialog.appendChild(formContainer);
    document.body.appendChild(dialog);

    // Function to generate subject inputs
    function generateSubjectInputs(subjects: Subject[]) {
      if (subjects.length === 0) {
        return `
          <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #ef4444;">
            <div style="margin-bottom: 1rem;">
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Subject Name</label>
              <input class="subject-name" type="text" placeholder="e.g. Math" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
                <input class="subject-q1" type="number" min="0" max="100" value="0" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
                <input class="subject-q2" type="number" min="0" max="100" value="0" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
                <input class="subject-q3" type="number" min="0" max="100" value="0" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
              <div>
                <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
                <input class="subject-q4" type="number" min="0" max="100" value="0" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
              </div>
            </div>
            <div style="display: flex; justify-content: flex-end; margin-top: 1rem;">
              <button class="remove-subject-btn" style="padding: 0.5rem 1rem; background-color: rgba(220, 38, 38, 0.2); border: 1px solid #dc2626; border-radius: 0.375rem; color: #ef4444; cursor: pointer; font-weight: 500;">Remove Subject</button>
            </div>
          </div>
        `;
      }

      return subjects
        .map(
          (subject, index) => `
        <div class="subject-row" style="background-color: #1f2937; border-radius: 0.375rem; padding: 1.25rem; margin-bottom: 1rem; border-left: 3px solid #ef4444;">
          <div style="margin-bottom: 1rem;">
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Subject Name</label>
            <input class="subject-name" type="text" value="${subject.name}" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
            <div>
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
              <input class="subject-q1" type="number" min="0" max="100" value="${subject.q1}" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
            </div>
            <div>
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
              <input class="subject-q2" type="number" min="0" max="100" value="${subject.q2}" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
            </div>
            <div>
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
              <input class="subject-q3" type="number" min="0" max="100" value="${subject.q3}" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
            </div>
            <div>
              <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
              <input class="subject-q4" type="number" min="0" max="100" value="${subject.q4}" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
            </div>
          </div>
          <div style="display: flex; justify-content: flex-end; margin-top: 1rem;">
            <button class="remove-subject-btn" style="padding: 0.5rem 1rem; background-color: rgba(220, 38, 38, 0.2); border: 1px solid #dc2626; border-radius: 0.375rem; color: #ef4444; cursor: pointer; font-weight: 500;">Remove Subject</button>
          </div>
        </div>
      `,
        )
        .join("");
    }

    // Add event listeners
    const addSubjectBtn = document.getElementById("add-subject-btn");
    const subjectsContainer = document.getElementById("subjects-container");
    const cancelBtn = document.getElementById("cancel-btn");
    const saveBtn = document.getElementById("save-btn");
    const closeBtn = document.getElementById("close-btn");

    // Add subject button
    addSubjectBtn?.addEventListener("click", () => {
      const newSubjectElement = document.createElement("div");
      newSubjectElement.className = "subject-row";
      newSubjectElement.style.backgroundColor = "#1f2937";
      newSubjectElement.style.borderRadius = "0.375rem";
      newSubjectElement.style.padding = "1.25rem";
      newSubjectElement.style.marginBottom = "1rem";
      newSubjectElement.style.borderLeft = "3px solid #ef4444";

      newSubjectElement.innerHTML = `
        <div style="margin-bottom: 1rem;">
          <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Subject Name</label>
          <input class="subject-name" type="text" placeholder="e.g. Math" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
        </div>
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.75rem;">
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q1</label>
            <input class="subject-q1" type="number" min="0" max="100" value="0" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q2</label>
            <input class="subject-q2" type="number" min="0" max="100" value="0" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q3</label>
            <input class="subject-q3" type="number" min="0" max="100" value="0" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; color: #d1d5db; font-weight: 500;">Q4</label>
            <input class="subject-q4" type="number" min="0" max="100" value="0" style="width: 100%; padding: 0.75rem; background-color: #111827; border: 1px solid #4b5563; border-radius: 0.375rem; color: white; font-size: 1rem;">
          </div>
        </div>
        <div style="display: flex; justify-content: flex-end; margin-top: 1rem;">
          <button class="remove-subject-btn" style="padding: 0.5rem 1rem; background-color: rgba(220, 38, 38, 0.2); border: 1px solid #dc2626; border-radius: 0.375rem; color: #ef4444; cursor: pointer; font-weight: 500;">Remove Subject</button>
        </div>
      `;

      subjectsContainer?.appendChild(newSubjectElement);

      // Add event listener to the new remove button
      const removeBtn = newSubjectElement.querySelector(".remove-subject-btn");
      removeBtn?.addEventListener("click", () => {
        newSubjectElement.remove();
      });
    });

    // Add event listeners to existing remove buttons
    document.querySelectorAll(".remove-subject-btn").forEach((button) => {
      button.addEventListener("click", (e) => {
        const subjectRow = (e.target as HTMLElement).closest(".subject-row");
        if (subjectRow) {
          subjectRow.remove();
        }
      });
    });

    // Cancel button
    cancelBtn?.addEventListener("click", () => {
      document.body.removeChild(dialog);
    });

    // Close button
    closeBtn?.addEventListener("click", () => {
      document.body.removeChild(dialog);
    });

    // Add event listener to ID picture URL input for edit form
    const idPictureInput = document.getElementById(
      "id-picture-url",
    ) as HTMLInputElement;
    const idPreview = document.getElementById("id-preview") as HTMLImageElement;
    const previewPlaceholder = document.getElementById("preview-placeholder");

    idPictureInput?.addEventListener("input", () => {
      const url = idPictureInput.value.trim();
      if (url) {
        idPreview.src = url;
        idPreview.style.display = "block";
        if (previewPlaceholder) previewPlaceholder.style.display = "none";

        // Handle image load error
        idPreview.onerror = () => {
          idPreview.style.display = "none";
          if (previewPlaceholder) previewPlaceholder.style.display = "block";
        };

        // Handle successful load
        idPreview.onload = () => {
          idPreview.style.display = "block";
          if (previewPlaceholder) previewPlaceholder.style.display = "none";
        };
      } else {
        idPreview.style.display = "none";
        if (previewPlaceholder) previewPlaceholder.style.display = "block";
      }
    });

    // Save button
    saveBtn?.addEventListener("click", () => {
      const nameInput = document.getElementById(
        "student-name",
      ) as HTMLInputElement;
      const emailInput = document.getElementById(
        "parent-email",
      ) as HTMLInputElement;
      const q1Input = document.getElementById("q1-grade") as HTMLInputElement;
      const q2Input = document.getElementById("q2-grade") as HTMLInputElement;
      const q3Input = document.getElementById("q3-grade") as HTMLInputElement;
      const q4Input = document.getElementById("q4-grade") as HTMLInputElement;
      const idPictureInput = document.getElementById(
        "id-picture-url",
      ) as HTMLInputElement;

      const updatedName = nameInput.value;
      const updatedEmail = emailInput.value;
      const updatedQ1 = parseInt(q1Input.value);
      const updatedQ2 = parseInt(q2Input.value);
      const updatedQ3 = parseInt(q3Input.value);
      const updatedQ4 = parseInt(q4Input.value);
      const updatedProfilePic =
        idPictureInput.value.trim() ||
        `https://api.dicebear.com/7.x/avataaars/svg?seed=${updatedName}`;

      if (!updatedName || !updatedEmail) {
        alert("Student name and parent email are required!");
        return;
      }

      // Collect subject data
      const updatedSubjects: Subject[] = [];
      document.querySelectorAll(".subject-row").forEach((row) => {
        const nameInput = row.querySelector(
          ".subject-name",
        ) as HTMLInputElement;
        const q1Input = row.querySelector(".subject-q1") as HTMLInputElement;
        const q2Input = row.querySelector(".subject-q2") as HTMLInputElement;
        const q3Input = row.querySelector(".subject-q3") as HTMLInputElement;
        const q4Input = row.querySelector(".subject-q4") as HTMLInputElement;

        const subjectName = nameInput.value.trim();
        if (subjectName) {
          const q1 = parseInt(q1Input.value) || 0;
          const q2 = parseInt(q2Input.value) || 0;
          const q3 = parseInt(q3Input.value) || 0;
          const q4 = parseInt(q4Input.value) || 0;
          const average = (q1 + q2 + q3 + q4) / 4;

          updatedSubjects.push({
            name: subjectName,
            type: determineSubjectType(subjectName),
            q1,
            q2,
            q3,
            q4,
            average,
          });
        }
      });

      const updatedAverage =
        (updatedQ1 + updatedQ2 + updatedQ3 + updatedQ4) / 4;

      const updatedStudents = students.map((s) => {
        if (s.id === student.id) {
          return {
            ...s,
            name: updatedName,
            parentEmail: updatedEmail,
            q1: updatedQ1,
            q2: updatedQ2,
            q3: updatedQ3,
            q4: updatedQ4,
            average: updatedAverage,
            subjects: updatedSubjects,
          };
        }
        return s;
      });

      setStudents(updatedStudents);
      localStorage.setItem("students", JSON.stringify(updatedStudents));

      // Also update in grade levels for student portal
      const gradeLevels = JSON.parse(
        localStorage.getItem("gradeLevels") || "[]",
      );
      const updatedGradeLevels = gradeLevels.map((gradeLevel: any) => ({
        ...gradeLevel,
        students: gradeLevel.students.map((s: any) => {
          if (s.id === student.id) {
            return {
              id: student.id,
              name: updatedName,
              lrn: updatedLRN,
              parentEmail: updatedEmail,
              profilePicture: updatedProfilePic,
              grades: {
                q1: updatedQ1,
                q2: updatedQ2,
                q3: updatedQ3,
                q4: updatedQ4,
              },
              subjects: updatedSubjects.map((subject) => ({
                name: subject.name,
                grades: {
                  q1: subject.q1,
                  q2: subject.q2,
                  q3: subject.q3,
                  q4: subject.q4,
                },
              })),
            };
          }
          return s;
        }),
      }));

      localStorage.setItem("gradeLevels", JSON.stringify(updatedGradeLevels));

      // Show success message with animation
      const successMessage = document.createElement("div");
      successMessage.style.position = "fixed";
      successMessage.style.top = "20px";
      successMessage.style.left = "50%";
      successMessage.style.transform = "translateX(-50%)";
      successMessage.style.backgroundColor = "rgba(16, 185, 129, 0.9)";
      successMessage.style.color = "white";
      successMessage.style.padding = "12px 24px";
      successMessage.style.borderRadius = "4px";
      successMessage.style.zIndex = "2000";
      successMessage.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
      successMessage.style.transition = "all 0.3s ease";
      successMessage.style.opacity = "0";
      successMessage.style.transform = "translateX(-50%) translateY(-20px)";
      successMessage.textContent = `Student ${updatedName} updated successfully`;

      document.body.appendChild(successMessage);

      setTimeout(() => {
        successMessage.style.opacity = "1";
        successMessage.style.transform = "translateX(-50%) translateY(0)";
      }, 10);

      setTimeout(() => {
        successMessage.style.opacity = "0";
        successMessage.style.transform = "translateX(-50%) translateY(-20px)";
        setTimeout(() => document.body.removeChild(successMessage), 300);
      }, 3000);

      // Fade out dialog
      dialog.style.opacity = "0";
      setTimeout(() => document.body.removeChild(dialog), 300);
    });

    // Using the determineSubjectType function defined earlier
  };

  const handleDeleteStudent = (studentId: string) => {
    if (window.confirm("Are you sure you want to delete this student?")) {
      // Remove from admin students list
      const updatedStudents = students.filter(
        (student) => student.id !== studentId,
      );
      setStudents(updatedStudents);
      localStorage.setItem("students", JSON.stringify(updatedStudents));

      // Also remove from grade levels for student portal
      const gradeLevels = JSON.parse(
        localStorage.getItem("gradeLevels") || "[]",
      );
      const updatedGradeLevels = gradeLevels.map((gradeLevel: any) => ({
        ...gradeLevel,
        students: gradeLevel.students.filter(
          (student: any) => student.id !== studentId,
        ),
      }));

      localStorage.setItem("gradeLevels", JSON.stringify(updatedGradeLevels));
    }
  };

  const handleViewStudent = (student: Student) => {
    // This would open a modal or navigate to view page
    alert(`View student: ${student.name}`);
  };

  return (
    <div
      className={`flex flex-col w-full min-h-screen ${theme === "dark" ? "bg-gradient-to-b from-blue-950 to-indigo-950 text-white" : "bg-gradient-to-b from-blue-50 to-indigo-100 text-gray-900"} p-4 md:p-6 transition-colors duration-300`}
    >
      <div className="max-w-7xl mx-auto">
        {showAddSuccess && (
          <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded-md shadow-lg z-50 animate-fade-in-down">
            {successMessage}
          </div>
        )}
        {showEditSuccess && (
          <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white px-6 py-3 rounded-md shadow-lg z-50 animate-fade-in-down">
            {successMessage}
          </div>
        )}
        {showDeleteSuccess && (
          <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-6 py-3 rounded-md shadow-lg z-50 animate-fade-in-down">
            {successMessage}
          </div>
        )}
        <style jsx>{`
          @keyframes fadeInDown {
            from {
              opacity: 0;
              transform: translate(-50%, -20px);
            }
            to {
              opacity: 1;
              transform: translate(-50%, 0);
            }
          }
          .animate-fade-in-down {
            animation: fadeInDown 0.5s ease forwards;
          }
          .card-hover {
            transition:
              transform 0.3s ease,
              box-shadow 0.3s ease;
          }
          .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
          }
        `}</style>
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 bg-clip-text text-transparent">
              ALDM Admin Dashboard
            </h1>
            <p
              className={`${theme === "dark" ? "text-gray-400" : "text-gray-600"} mt-1`}
            >
              Welcome back, {currentUser?.username || "Admin"}
            </p>
          </div>

          <div className="flex space-x-2">
            <Button
              onClick={toggleTheme}
              variant="outline"
              className={`${theme === "dark" ? "border-blue-500 text-blue-400" : "border-blue-600 text-blue-600"} transition-all duration-300`}
            >
              {theme === "dark" ? "☀️ Light Mode" : "🌙 Dark Mode"}
            </Button>
            <Button
              onClick={handleLogout}
              variant="destructive"
              className="bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 transition-all duration-300"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card
            className={`${theme === "dark" ? "bg-blue-900/50" : "bg-white"} border border-blue-500 shadow-lg card-hover transition-all duration-300`}
          >
            <CardHeader className="pb-2 bg-gradient-to-r from-blue-600 to-indigo-600">
              <CardTitle className="text-lg font-medium text-white">
                Total Students
              </CardTitle>
              <CardDescription className="text-gray-200">
                Across all grade levels
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="flex items-center">
                <Users
                  className={`h-8 w-8 ${theme === "dark" ? "text-blue-400" : "text-blue-600"} mr-3`}
                />
                <span
                  className={`text-3xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}
                >
                  {students.length}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card
            className={`${theme === "dark" ? "bg-blue-900/50" : "bg-white"} border border-blue-500 shadow-lg card-hover transition-all duration-300`}
          >
            <CardHeader className="pb-2 bg-gradient-to-r from-blue-600 to-indigo-600">
              <CardTitle className="text-lg font-medium text-white">
                Grade Reports
              </CardTitle>
              <CardDescription className="text-gray-200">
                Generated this quarter
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="flex items-center">
                <FileText
                  className={`h-8 w-8 ${theme === "dark" ? "text-green-400" : "text-green-600"} mr-3`}
                />
                <span
                  className={`text-3xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}
                >
                  24
                </span>
              </div>
            </CardContent>
          </Card>

          <Card
            className={`${theme === "dark" ? "bg-blue-900/50" : "bg-white"} border border-blue-500 shadow-lg card-hover transition-all duration-300`}
          >
            <CardHeader className="pb-2 bg-gradient-to-r from-blue-600 to-indigo-600">
              <CardTitle className="text-lg font-medium text-white">
                Messages Sent
              </CardTitle>
              <CardDescription className="text-gray-200">
                To parents this month
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="flex items-center">
                <Mail
                  className={`h-8 w-8 ${theme === "dark" ? "text-amber-400" : "text-amber-600"} mr-3`}
                />
                <span
                  className={`text-3xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}
                >
                  18
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card
          className={`${theme === "dark" ? "bg-blue-950" : "bg-white"} border-blue-500 border flex-1 shadow-lg transition-all duration-300`}
        >
          <CardHeader>
            <CardTitle
              className={theme === "dark" ? "text-white" : "text-gray-900"}
            >
              Student Records
            </CardTitle>
            <CardDescription
              className={theme === "dark" ? "text-gray-400" : "text-gray-600"}
            >
              Manage student data, grades, and communications
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all-students" className="w-full">
              <TabsList
                className={`grid grid-cols-2 md:grid-cols-3 mb-6 ${theme === "dark" ? "bg-blue-900/50" : "bg-blue-100"} transition-colors duration-300`}
              >
                <TabsTrigger
                  value="all-students"
                  className="data-[state=active]:bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-300"
                >
                  <Users className="h-4 w-4 mr-2 hidden md:block" />
                  All Students
                </TabsTrigger>
                <TabsTrigger
                  value="grade-levels"
                  className="data-[state=active]:bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-300"
                >
                  <GraduationCap className="h-4 w-4 mr-2 hidden md:block" />
                  Grade Levels
                </TabsTrigger>
                <TabsTrigger
                  value="reports"
                  className="data-[state=active]:bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-300"
                >
                  <FileText className="h-4 w-4 mr-2 hidden md:block" />
                  Reports
                </TabsTrigger>
              </TabsList>

              <TabsContent value="all-students" className="space-y-4">
                <div className="flex flex-col md:flex-row gap-4 mb-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search students by name or email..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className={`pl-10 ${theme === "dark" ? "bg-blue-900 border-blue-700 text-white" : "bg-blue-50 border-blue-200 text-gray-900"} w-full transition-colors duration-300`}
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={handleAddStudent}
                      className="bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white transition-all duration-300"
                    >
                      + Add Student
                    </Button>

                    <Select
                      value={selectedGradeLevel}
                      onValueChange={setSelectedGradeLevel}
                    >
                      <SelectTrigger className="w-full md:w-[180px] bg-blue-900 border-blue-700 text-white">
                        <SelectValue placeholder="Grade Level" />
                      </SelectTrigger>
                      <SelectContent className="border-blue-700 bg-blue-900 text-white">
                        <SelectItem value="all">All Grades</SelectItem>
                        <SelectItem value="7">Grade 7</SelectItem>
                        <SelectItem value="8">Grade 8</SelectItem>
                        <SelectItem value="9">Grade 9</SelectItem>
                        <SelectItem value="10">Grade 10</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <StudentTable
                  students={filteredStudents}
                  onSendEmail={handleSendEmail}
                  onEdit={handleEditStudent}
                  onDelete={handleDeleteStudent}
                  onView={handleViewStudent}
                  allowEdit={true}
                  allowDelete={true}
                />
              </TabsContent>

              <TabsContent value="grade-levels">
                <GradeLevelDashboard />
              </TabsContent>

              <TabsContent value="reports">
                <div className="p-6 rounded-lg bg-blue-950 border-blue-500 border">
                  <div className="text-center mb-6">
                    <FileText className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                    <h3 className="text-xl font-bold text-white">
                      Grade Reports
                    </h3>
                    <p className="text-gray-400">
                      Generate and send comprehensive grade reports to parents
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card
                      style={{
                        background: "#000000",
                        border: "2px solid transparent",
                        borderImageSlice: "1",
                        borderImageSource:
                          "linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet)",
                      }}
                    >
                      <CardHeader
                        style={{
                          background: "linear-gradient(to right, #500, #800)",
                        }}
                      >
                        <CardTitle className="text-lg">
                          Individual Reports
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-400 mb-4">
                          Generate detailed reports for individual students
                        </p>
                        <Button
                          className="w-full"
                          style={{
                            background:
                              "linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet)",
                          }}
                        >
                          Generate Individual Report
                        </Button>
                      </CardContent>
                    </Card>

                    <Card
                      style={{
                        background: "#000000",
                        border: "2px solid transparent",
                        borderImageSlice: "1",
                        borderImageSource:
                          "linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet)",
                      }}
                    >
                      <CardHeader
                        style={{
                          background: "linear-gradient(to right, #500, #800)",
                        }}
                      >
                        <CardTitle className="text-lg">Class Reports</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-400 mb-4">
                          Generate reports for entire grade levels
                        </p>
                        <Button
                          className="w-full"
                          style={{
                            background:
                              "linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet)",
                          }}
                        >
                          Generate Class Report
                        </Button>
                      </CardContent>
                    </Card>

                    <Card
                      style={{
                        background: "#000000",
                        border: "2px solid transparent",
                        borderImageSlice: "1",
                        borderImageSource:
                          "linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet)",
                      }}
                    >
                      <CardHeader
                        style={{
                          background: "linear-gradient(to right, #500, #800)",
                        }}
                      >
                        <CardTitle className="text-lg">
                          Scheduled Reports
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-400 mb-4">
                          Set up automated quarterly reports
                        </p>
                        <Button
                          className="w-full"
                          style={{
                            background:
                              "linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet)",
                          }}
                        >
                          Schedule Reports
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Helper function to generate empty student array
function generateSampleStudents(): Student[] {
  return [];
}

export default AdminDashboard;
