import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Send, User, Users, Clock, Search } from "lucide-react";

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

interface Contact {
  id: string;
  name: string;
  role: "admin" | "student" | "parent";
  lastMessage?: string;
  lastMessageTime?: string;
  unreadCount?: number;
  avatar?: string;
}

const MessagingSystem = () => {
  const [currentUser, setCurrentUser] = useState<{
    username: string;
    role: string;
    id: string;
  } | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  // Initialize with sample data
  useEffect(() => {
    // Get current user from localStorage
    const userStr = localStorage.getItem("currentUser");
    if (userStr) {
      const user = JSON.parse(userStr);
      // Add an ID for the current user
      setCurrentUser({
        ...user,
        id:
          user.role === "admin"
            ? "admin-1"
            : `student-${Math.floor(Math.random() * 1000)}`,
      });
    }

    // Load sample contacts
    setContacts(generateSampleContacts());

    // Load sample messages
    setMessages(generateSampleMessages());
  }, []);

  // Filter contacts based on search term
  const filteredContacts = contacts.filter((contact) =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  // Get messages for selected contact
  const contactMessages = selectedContact
    ? messages
        .filter(
          (message) =>
            (message.senderId === currentUser?.id &&
              message.receiverId === selectedContact.id) ||
            (message.receiverId === currentUser?.id &&
              message.senderId === selectedContact.id),
        )
        .sort(
          (a, b) =>
            new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(),
        )
    : [];

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedContact || !currentUser) return;

    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.username,
      receiverId: selectedContact.id,
      receiverName: selectedContact.name,
      content: newMessage,
      timestamp: new Date().toISOString(),
      isRead: false,
    };

    setMessages([...messages, newMsg]);
    setNewMessage("");

    // Update last message in contacts
    const updatedContacts = contacts.map((contact) => {
      if (contact.id === selectedContact.id) {
        return {
          ...contact,
          lastMessage: newMessage,
          lastMessageTime: new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
        };
      }
      return contact;
    });
    setContacts(updatedContacts);
  };

  const selectContact = (contact: Contact) => {
    setSelectedContact(contact);

    // Mark messages as read
    const updatedMessages = messages.map((message) => {
      if (
        message.senderId === contact.id &&
        message.receiverId === currentUser?.id &&
        !message.isRead
      ) {
        return { ...message, isRead: true };
      }
      return message;
    });
    setMessages(updatedMessages);

    // Update unread count
    const updatedContacts = contacts.map((c) => {
      if (c.id === contact.id) {
        return { ...c, unreadCount: 0 };
      }
      return c;
    });
    setContacts(updatedContacts);
  };

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <Card className="w-full h-[calc(100vh-2rem)] border border-red-500 bg-gray-800 overflow-hidden">
        <CardHeader className="p-4 border-b border-gray-700">
          <CardTitle className="text-xl bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 bg-clip-text text-transparent">
            ALDM Messaging System
          </CardTitle>
          <CardDescription className="text-gray-400">
            Communicate with students, parents, and administrators
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0 flex h-[calc(100%-8rem)]">
          <Tabs defaultValue="contacts" className="w-full h-full flex">
            <div className="w-1/3 border-r border-gray-700 h-full flex flex-col">
              <TabsList className="grid w-full grid-cols-2 bg-gray-700 rounded-none">
                <TabsTrigger
                  value="contacts"
                  className="data-[state=active]:bg-gray-600 rounded-none"
                >
                  <Users className="h-4 w-4 mr-2" />
                  Contacts
                </TabsTrigger>
                <TabsTrigger
                  value="recent"
                  className="data-[state=active]:bg-gray-600 rounded-none"
                >
                  <Clock className="h-4 w-4 mr-2" />
                  Recent
                </TabsTrigger>
              </TabsList>

              <div className="p-3 border-b border-gray-700">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search contacts..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8 bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>

              <TabsContent
                value="contacts"
                className="flex-1 p-0 m-0 overflow-hidden"
              >
                <ScrollArea className="h-full">
                  <div className="divide-y divide-gray-700">
                    {filteredContacts.map((contact) => (
                      <div
                        key={contact.id}
                        className={`flex items-center p-3 cursor-pointer hover:bg-gray-700 ${selectedContact?.id === contact.id ? "bg-gray-700" : ""}`}
                        onClick={() => selectContact(contact)}
                      >
                        <Avatar className="h-10 w-10 mr-3">
                          <AvatarImage src={contact.avatar} />
                          <AvatarFallback className="bg-gray-600 text-white">
                            {contact.name.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-center">
                            <p className="text-sm font-medium truncate">
                              {contact.name}
                            </p>
                            <span className="text-xs text-gray-400">
                              {contact.role === "admin"
                                ? "Admin"
                                : contact.role === "parent"
                                  ? "Parent"
                                  : "Student"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent
                value="recent"
                className="flex-1 p-0 m-0 overflow-hidden"
              >
                <ScrollArea className="h-full">
                  <div className="divide-y divide-gray-700">
                    {contacts
                      .filter((contact) => contact.lastMessage)
                      .sort((a, b) => {
                        if (!a.lastMessageTime || !b.lastMessageTime) return 0;
                        return (
                          new Date(b.lastMessageTime).getTime() -
                          new Date(a.lastMessageTime).getTime()
                        );
                      })
                      .map((contact) => (
                        <div
                          key={contact.id}
                          className={`flex items-center p-3 cursor-pointer hover:bg-gray-700 ${selectedContact?.id === contact.id ? "bg-gray-700" : ""}`}
                          onClick={() => selectContact(contact)}
                        >
                          <Avatar className="h-10 w-10 mr-3">
                            <AvatarImage src={contact.avatar} />
                            <AvatarFallback className="bg-gray-600 text-white">
                              {contact.name.substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-center">
                              <p className="text-sm font-medium truncate">
                                {contact.name}
                              </p>
                              <span className="text-xs text-gray-400">
                                {contact.lastMessageTime}
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-400 truncate">
                                {contact.lastMessage}
                              </p>
                              {contact.unreadCount ? (
                                <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-red-500 text-white text-xs">
                                  {contact.unreadCount}
                                </span>
                              ) : null}
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            </div>

            <div className="w-2/3 flex flex-col h-full">
              {selectedContact ? (
                <>
                  <div className="p-3 border-b border-gray-700 flex items-center">
                    <Avatar className="h-8 w-8 mr-2">
                      <AvatarImage src={selectedContact.avatar} />
                      <AvatarFallback className="bg-gray-600 text-white">
                        {selectedContact.name.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{selectedContact.name}</p>
                      <p className="text-xs text-gray-400">
                        {selectedContact.role === "admin"
                          ? "Administrator"
                          : selectedContact.role === "parent"
                            ? "Parent"
                            : "Student"}
                      </p>
                    </div>
                  </div>

                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-4">
                      {contactMessages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.senderId === currentUser?.id ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-[70%] rounded-lg p-3 ${
                              message.senderId === currentUser?.id
                                ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                                : "bg-gray-700 text-white"
                            }`}
                          >
                            <p className="text-sm">{message.content}</p>
                            <p className="text-xs text-gray-200 mt-1 text-right">
                              {formatMessageTime(message.timestamp)}
                              {message.senderId === currentUser?.id && (
                                <span className="ml-1">
                                  {message.isRead ? "✓✓" : "✓"}
                                </span>
                              )}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>

                  <div className="p-3 border-t border-gray-700 flex items-center">
                    <Textarea
                      placeholder="Type your message..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      className="flex-1 bg-gray-700 border-gray-600 text-white resize-none"
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                    />
                    <Button
                      onClick={handleSendMessage}
                      className="ml-2 bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:from-purple-600 hover:via-pink-600 hover:to-red-600"
                      size="icon"
                      disabled={!newMessage.trim()}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-gray-400">
                  <User className="h-16 w-16 mb-4 text-gray-600" />
                  <p className="text-lg font-medium">
                    Select a contact to start messaging
                  </p>
                  <p className="text-sm">
                    You can communicate with administrators, students, and
                    parents
                  </p>
                </div>
              )}
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

// Helper function to generate sample contacts
function generateSampleContacts(): Contact[] {
  return [
    {
      id: "admin-1",
      name: "DepedAmaba",
      role: "admin",
      lastMessage: "Please submit your quarterly reports by Friday.",
      lastMessageTime: "09:45",
      unreadCount: 0,
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=admin1",
    },
    {
      id: "student-1",
      name: "John Doe",
      role: "student",
      lastMessage: "Thank you for the feedback on my project.",
      lastMessageTime: "Yesterday",
      unreadCount: 0,
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=john",
    },
    {
      id: "parent-1",
      name: "Maria Garcia",
      role: "parent",
      lastMessage: "When is the next parent-teacher meeting?",
      lastMessageTime: "Monday",
      unreadCount: 2,
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=maria",
    },
    {
      id: "student-2",
      name: "Emily Williams",
      role: "student",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=emily",
    },
    {
      id: "parent-2",
      name: "Robert Johnson",
      role: "parent",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=robert",
    },
    {
      id: "student-3",
      name: "Michael Brown",
      role: "student",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=michael",
    },
    {
      id: "parent-3",
      name: "Jennifer Lee",
      role: "parent",
      lastMessage:
        "My son will be absent tomorrow due to a doctor's appointment.",
      lastMessageTime: "Tuesday",
      unreadCount: 0,
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=jennifer",
    },
    {
      id: "student-4",
      name: "David Wilson",
      role: "student",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=david",
    },
    {
      id: "parent-4",
      name: "Patricia Martinez",
      role: "parent",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=patricia",
    },
    {
      id: "student-5",
      name: "Sarah Taylor",
      role: "student",
      lastMessage: "I've submitted my assignment on the portal.",
      lastMessageTime: "Wednesday",
      unreadCount: 1,
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=sarah",
    },
  ];
}

// Helper function to generate sample messages
function generateSampleMessages(): Message[] {
  return [
    {
      id: "msg-1",
      senderId: "admin-1",
      senderName: "DepedAmaba",
      receiverId: "student-1",
      receiverName: "John Doe",
      content: "Hello John, how is your project coming along?",
      timestamp: "2023-05-10T09:30:00Z",
      isRead: true,
    },
    {
      id: "msg-2",
      senderId: "student-1",
      senderName: "John Doe",
      receiverId: "admin-1",
      receiverName: "DepedAmaba",
      content: "It's going well! I should be able to submit it by tomorrow.",
      timestamp: "2023-05-10T09:35:00Z",
      isRead: true,
    },
    {
      id: "msg-3",
      senderId: "admin-1",
      senderName: "DepedAmaba",
      receiverId: "student-1",
      receiverName: "John Doe",
      content: "Great! Let me know if you need any help.",
      timestamp: "2023-05-10T09:40:00Z",
      isRead: true,
    },
    {
      id: "msg-4",
      senderId: "student-1",
      senderName: "John Doe",
      receiverId: "admin-1",
      receiverName: "DepedAmaba",
      content: "Thank you for the feedback on my project.",
      timestamp: "2023-05-10T09:45:00Z",
      isRead: true,
    },
    {
      id: "msg-5",
      senderId: "parent-1",
      senderName: "Maria Garcia",
      receiverId: "admin-1",
      receiverName: "DepedAmaba",
      content:
        "Hello, I wanted to ask about my daughter's progress in Math class.",
      timestamp: "2023-05-09T14:20:00Z",
      isRead: true,
    },
    {
      id: "msg-6",
      senderId: "admin-1",
      senderName: "DepedAmaba",
      receiverId: "parent-1",
      receiverName: "Maria Garcia",
      content:
        "Hi Maria, your daughter is doing very well. She scored 92% on the last test.",
      timestamp: "2023-05-09T14:25:00Z",
      isRead: true,
    },
    {
      id: "msg-7",
      senderId: "parent-1",
      senderName: "Maria Garcia",
      receiverId: "admin-1",
      receiverName: "DepedAmaba",
      content:
        "That's wonderful to hear! When is the next parent-teacher meeting?",
      timestamp: "2023-05-09T14:30:00Z",
      isRead: false,
    },
    {
      id: "msg-8",
      senderId: "parent-1",
      senderName: "Maria Garcia",
      receiverId: "admin-1",
      receiverName: "DepedAmaba",
      content: "Also, will there be any special projects this quarter?",
      timestamp: "2023-05-09T14:32:00Z",
      isRead: false,
    },
    {
      id: "msg-9",
      senderId: "student-5",
      senderName: "Sarah Taylor",
      receiverId: "admin-1",
      receiverName: "DepedAmaba",
      content: "I've submitted my assignment on the portal.",
      timestamp: "2023-05-08T16:15:00Z",
      isRead: false,
    },
    {
      id: "msg-10",
      senderId: "parent-3",
      senderName: "Jennifer Lee",
      receiverId: "admin-1",
      receiverName: "DepedAmaba",
      content: "My son will be absent tomorrow due to a doctor's appointment.",
      timestamp: "2023-05-07T10:05:00Z",
      isRead: true,
    },
  ];
}

export default MessagingSystem;
