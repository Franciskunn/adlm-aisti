import { useState, useEffect } from "react";
import { useTheme } from "./ThemeProvider";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { GraduationCap, Users, FileText, LogOut } from "lucide-react";

interface DashboardProps {
  onLogout?: () => void;
}

const Dashboard = ({ onLogout }: DashboardProps) => {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const [currentUser, setCurrentUser] = useState<{
    username: string;
    role: string;
  } | null>(null);

  useEffect(() => {
    const userStr = localStorage.getItem("currentUser");
    if (!userStr) {
      navigate("/");
      return;
    }

    const user = JSON.parse(userStr);
    setCurrentUser(user);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("currentUser");
    if (onLogout) {
      onLogout();
    }
    navigate("/");
  };

  const navigateToPortal = () => {
    if (currentUser?.role === "admin") {
      navigate("/admin");
    } else {
      navigate("/student");
    }
  };

  return (
    <div
      className={`flex flex-col w-full min-h-screen ${theme === "dark" ? "bg-gradient-to-b from-blue-950 to-indigo-950 text-white" : "bg-gradient-to-b from-blue-50 to-indigo-100 text-gray-900"} p-4 md:p-6 transition-colors duration-300`}
    >
      <style jsx>{`
        .card-hover {
          transition:
            transform 0.3s ease,
            box-shadow 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        .button-hover {
          transition: transform 0.2s ease;
        }
        .button-hover:active {
          transform: scale(0.95);
        }
        .fade-in {
          animation: fadeIn 0.5s ease-in;
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
      <div className="flex justify-between items-center mb-6">
        <h1
          className={`text-2xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}
        >
          ALDM Education Portal
        </h1>
        <div className="flex space-x-2">
          <Button
            onClick={toggleTheme}
            variant="outline"
            className={`${theme === "dark" ? "border-blue-500 text-blue-400" : "border-blue-600 text-blue-600"} transition-all duration-300 button-hover`}
          >
            {theme === "dark" ? "☀️ Light Mode" : "🌙 Dark Mode"}
          </Button>
          <Button
            variant="destructive"
            onClick={handleLogout}
            className="bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 button-hover transition-all duration-300"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      <div className="flex flex-col items-center justify-center flex-1 text-center">
        <div className="mb-8">
          <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-400 via-indigo-400 to-violet-400 bg-clip-text text-transparent mb-4">
            Welcome, {currentUser?.username || "User"}!
          </h2>
          <p
            className={`text-xl ${theme === "dark" ? "text-gray-300" : "text-gray-600"} max-w-2xl mx-auto`}
          >
            Access your{" "}
            {currentUser?.role === "admin"
              ? "administrative dashboard"
              : "student portal"}{" "}
            to view and manage academic records.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl">
          <Card
            className={`${theme === "dark" ? "bg-blue-950 border-blue-500" : "bg-white border-blue-300"} border hover:shadow-lg transition-all duration-300 hover:border-blue-400 card-hover fade-in`}
          >
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <GraduationCap className="h-5 w-5 mr-2 text-blue-400" />
                Academic Records
              </CardTitle>
              <CardDescription className="text-gray-400">
                View grades and academic performance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={navigateToPortal}
                className="w-full bg-gradient-to-r from-blue-700 to-violet-700 hover:from-blue-800 hover:to-violet-800 button-hover transition-all duration-300"
              >
                Access Records
              </Button>
            </CardContent>
          </Card>

          <Card
            className={`${theme === "dark" ? "bg-blue-950 border-blue-500" : "bg-white border-blue-300"} border hover:shadow-lg transition-all duration-300 hover:border-blue-400 card-hover fade-in`}
          >
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Users className="h-5 w-5 mr-2 text-blue-400" />
                {currentUser?.role === "admin"
                  ? "Student Management"
                  : "Personal Profile"}
              </CardTitle>
              <CardDescription className="text-gray-400">
                {currentUser?.role === "admin"
                  ? "Manage student information"
                  : "Update your information"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={navigateToPortal}
                className="w-full bg-gradient-to-r from-blue-700 to-violet-700 hover:from-blue-800 hover:to-violet-800 button-hover transition-all duration-300"
              >
                {currentUser?.role === "admin"
                  ? "Manage Students"
                  : "View Profile"}
              </Button>
            </CardContent>
          </Card>

          <Card
            className={`${theme === "dark" ? "bg-blue-950 border-blue-500" : "bg-white border-blue-300"} border hover:shadow-lg transition-all duration-300 hover:border-blue-400 card-hover fade-in`}
          >
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <FileText className="h-5 w-5 mr-2 text-blue-400" />
                Reports
              </CardTitle>
              <CardDescription className="text-gray-400">
                {currentUser?.role === "admin"
                  ? "Generate and send reports"
                  : "View and download reports"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={navigateToPortal}
                className="w-full bg-gradient-to-r from-blue-700 to-violet-700 hover:from-blue-800 hover:to-violet-800 button-hover transition-all duration-300"
              >
                Access Reports
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
