import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Send, Save, Plus, Trash } from "lucide-react";

interface Subject {
  name: string;
  type:
    | "Mathematics"
    | "Science"
    | "English"
    | "Filipino"
    | "MAPEH"
    | "Araling Panlipunan"
    | "ESP"
    | "TLE";
  q1: number;
  q2: number;
  q3: number;
  q4: number;
  average: number;
}

interface Student {
  id: string;
  name: string;
  parentEmail: string;
  gradeLevel: 7 | 8 | 9 | 10;
  q1: number;
  q2: number;
  q3: number;
  q4: number;
  average: number;
  subjects: Subject[];
}

interface ExcelStyleTableProps {
  initialStudents?: Student[];
  onSave?: (students: Student[]) => void;
  onSendEmail?: (email: string, student: Student) => void;
  readOnly?: boolean;
}

const defaultSubjects: Subject[] = [
  {
    name: "Mathematics",
    type: "Mathematics",
    q1: 0,
    q2: 0,
    q3: 0,
    q4: 0,
    average: 0,
  },
  { name: "Science", type: "Science", q1: 0, q2: 0, q3: 0, q4: 0, average: 0 },
  { name: "English", type: "English", q1: 0, q2: 0, q3: 0, q4: 0, average: 0 },
  {
    name: "Filipino",
    type: "Filipino",
    q1: 0,
    q2: 0,
    q3: 0,
    q4: 0,
    average: 0,
  },
  { name: "MAPEH", type: "MAPEH", q1: 0, q2: 0, q3: 0, q4: 0, average: 0 },
  {
    name: "Araling Panlipunan",
    type: "Araling Panlipunan",
    q1: 0,
    q2: 0,
    q3: 0,
    q4: 0,
    average: 0,
  },
  { name: "ESP", type: "ESP", q1: 0, q2: 0, q3: 0, q4: 0, average: 0 },
  { name: "TLE", type: "TLE", q1: 0, q2: 0, q3: 0, q4: 0, average: 0 },
];

const ExcelStyleTable: React.FC<ExcelStyleTableProps> = ({
  initialStudents = [],
  onSave,
  onSendEmail,
  readOnly = false,
}) => {
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [selectedQuarter, setSelectedQuarter] = useState<
    "all" | "q1" | "q2" | "q3" | "q4"
  >("all");
  const [newStudent, setNewStudent] = useState<{
    name: string;
    parentEmail: string;
    gradeLevel: 7 | 8 | 9 | 10;
  }>({
    name: "",
    parentEmail: "",
    gradeLevel: 7,
  });

  // Calculate averages whenever student data changes
  useEffect(() => {
    if (students.length > 0) {
      const updatedStudents = students.map((student) => {
        // Update subject averages
        const updatedSubjects = student.subjects.map((subject) => {
          const average =
            (subject.q1 + subject.q2 + subject.q3 + subject.q4) / 4;
          return { ...subject, average };
        });

        // Calculate overall averages
        const q1Avg =
          updatedSubjects.reduce((sum, subject) => sum + subject.q1, 0) /
          updatedSubjects.length;
        const q2Avg =
          updatedSubjects.reduce((sum, subject) => sum + subject.q2, 0) /
          updatedSubjects.length;
        const q3Avg =
          updatedSubjects.reduce((sum, subject) => sum + subject.q3, 0) /
          updatedSubjects.length;
        const q4Avg =
          updatedSubjects.reduce((sum, subject) => sum + subject.q4, 0) /
          updatedSubjects.length;
        const overallAvg = (q1Avg + q2Avg + q3Avg + q4Avg) / 4;

        return {
          ...student,
          subjects: updatedSubjects,
          q1: Math.round(q1Avg * 10) / 10,
          q2: Math.round(q2Avg * 10) / 10,
          q3: Math.round(q3Avg * 10) / 10,
          q4: Math.round(q4Avg * 10) / 10,
          average: Math.round(overallAvg * 10) / 10,
        };
      });

      setStudents(updatedStudents);
      if (onSave) {
        onSave(updatedStudents);
      }
    }
  }, []);

  const handleAddStudent = () => {
    if (!newStudent.name || !newStudent.parentEmail) return;

    const newStudentData: Student = {
      id: Date.now().toString(),
      ...newStudent,
      q1: 0,
      q2: 0,
      q3: 0,
      q4: 0,
      average: 0,
      subjects: JSON.parse(JSON.stringify(defaultSubjects)),
    };

    const updatedStudents = [...students, newStudentData];
    setStudents(updatedStudents);
    if (onSave) {
      onSave(updatedStudents);
    }

    // Reset form
    setNewStudent({
      name: "",
      parentEmail: "",
      gradeLevel: 7,
    });
  };

  const handleRemoveStudent = (id: string) => {
    const updatedStudents = students.filter((student) => student.id !== id);
    setStudents(updatedStudents);
    if (onSave) {
      onSave(updatedStudents);
    }
  };

  const handleGradeChange = (
    studentId: string,
    subjectIndex: number,
    quarter: "q1" | "q2" | "q3" | "q4",
    value: number,
  ) => {
    if (readOnly) return;

    const updatedStudents = students.map((student) => {
      if (student.id === studentId) {
        const updatedSubjects = [...student.subjects];
        updatedSubjects[subjectIndex] = {
          ...updatedSubjects[subjectIndex],
          [quarter]: value,
        };

        // Update subject average
        const subject = updatedSubjects[subjectIndex];
        const average = (subject.q1 + subject.q2 + subject.q3 + subject.q4) / 4;
        updatedSubjects[subjectIndex].average = Math.round(average * 10) / 10;

        // Calculate overall averages
        const q1Avg =
          updatedSubjects.reduce((sum, subject) => sum + subject.q1, 0) /
          updatedSubjects.length;
        const q2Avg =
          updatedSubjects.reduce((sum, subject) => sum + subject.q2, 0) /
          updatedSubjects.length;
        const q3Avg =
          updatedSubjects.reduce((sum, subject) => sum + subject.q3, 0) /
          updatedSubjects.length;
        const q4Avg =
          updatedSubjects.reduce((sum, subject) => sum + subject.q4, 0) /
          updatedSubjects.length;
        const overallAvg = (q1Avg + q2Avg + q3Avg + q4Avg) / 4;

        return {
          ...student,
          subjects: updatedSubjects,
          q1: Math.round(q1Avg * 10) / 10,
          q2: Math.round(q2Avg * 10) / 10,
          q3: Math.round(q3Avg * 10) / 10,
          q4: Math.round(q4Avg * 10) / 10,
          average: Math.round(overallAvg * 10) / 10,
        };
      }
      return student;
    });

    setStudents(updatedStudents);
    if (onSave) {
      onSave(updatedStudents);
    }
  };

  const handleSendEmail = (student: Student) => {
    if (onSendEmail) {
      onSendEmail(student.parentEmail, student);
    } else {
      alert(
        `Email would be sent to ${student.parentEmail} with ${student.name}'s grades`,
      );
    }
  };

  const handleSaveAll = () => {
    if (onSave) {
      onSave(students);
      alert("All student data saved successfully!");
    }
  };

  // Get grade status color
  const getGradeStatusColor = (grade: number) => {
    if (grade >= 90) return "bg-green-600";
    if (grade >= 75) return "bg-blue-600";
    return "bg-red-600";
  };

  return (
    <div className="space-y-6 bg-gray-900 p-4 rounded-lg border border-red-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-xl font-bold text-white">
          Student Grade Management
        </h2>

        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
          <Select
            value={selectedQuarter}
            onValueChange={(value) => setSelectedQuarter(value as any)}
          >
            <SelectTrigger className="w-full sm:w-[180px] bg-gray-800 border-gray-700 text-white">
              <SelectValue placeholder="Select Quarter" />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-700 text-white">
              <SelectItem value="all">All Quarters</SelectItem>
              <SelectItem value="q1">Quarter 1</SelectItem>
              <SelectItem value="q2">Quarter 2</SelectItem>
              <SelectItem value="q3">Quarter 3</SelectItem>
              <SelectItem value="q4">Quarter 4</SelectItem>
            </SelectContent>
          </Select>

          {!readOnly && (
            <Button
              onClick={handleSaveAll}
              className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white"
            >
              <Save className="mr-2 h-4 w-4" />
              Save All Changes
            </Button>
          )}
        </div>
      </div>

      {!readOnly && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-4 bg-gray-800 rounded-lg border border-gray-700">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">
              Student Name
            </label>
            <Input
              value={newStudent.name}
              onChange={(e) =>
                setNewStudent({ ...newStudent, name: e.target.value })
              }
              placeholder="Enter student name"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">
              Grade Level
            </label>
            <Select
              value={newStudent.gradeLevel.toString()}
              onValueChange={(value) =>
                setNewStudent({
                  ...newStudent,
                  gradeLevel: parseInt(value) as 7 | 8 | 9 | 10,
                })
              }
            >
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Select grade level" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700 text-white">
                <SelectItem value="7">Grade 7</SelectItem>
                <SelectItem value="8">Grade 8</SelectItem>
                <SelectItem value="9">Grade 9</SelectItem>
                <SelectItem value="10">Grade 10</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">
              Parent Email
            </label>
            <div className="flex gap-2">
              <Input
                value={newStudent.parentEmail}
                onChange={(e) =>
                  setNewStudent({ ...newStudent, parentEmail: e.target.value })
                }
                placeholder="Enter parent email"
                className="bg-gray-700 border-gray-600 text-white"
              />
              <Button
                onClick={handleAddStudent}
                className="bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:from-purple-600 hover:via-pink-600 hover:to-red-600 text-white"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="overflow-x-auto rounded-md border border-red-500">
        <Table>
          <TableHeader className="bg-gradient-to-r from-purple-900 to-pink-900">
            <TableRow>
              <TableHead className="text-gray-100 font-semibold">
                Student
              </TableHead>
              <TableHead className="text-gray-100 font-semibold">
                Grade
              </TableHead>
              <TableHead className="text-gray-100 font-semibold">
                Parent Email
              </TableHead>
              {selectedQuarter === "all" || selectedQuarter === "q1" ? (
                <TableHead className="text-gray-100 font-semibold">
                  Q1
                </TableHead>
              ) : null}
              {selectedQuarter === "all" || selectedQuarter === "q2" ? (
                <TableHead className="text-gray-100 font-semibold">
                  Q2
                </TableHead>
              ) : null}
              {selectedQuarter === "all" || selectedQuarter === "q3" ? (
                <TableHead className="text-gray-100 font-semibold">
                  Q3
                </TableHead>
              ) : null}
              {selectedQuarter === "all" || selectedQuarter === "q4" ? (
                <TableHead className="text-gray-100 font-semibold">
                  Q4
                </TableHead>
              ) : null}
              <TableHead className="text-gray-100 font-semibold">
                Average
              </TableHead>
              <TableHead className="text-gray-100 font-semibold">
                Actions
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {students.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={8}
                  className="text-center py-8 text-gray-400"
                >
                  No students found. Add a student to get started.
                </TableCell>
              </TableRow>
            ) : (
              students.map((student) => (
                <React.Fragment key={student.id}>
                  {/* Student row */}
                  <TableRow className="border-t border-gray-700 hover:bg-gray-800 bg-opacity-50">
                    <TableCell className="font-medium text-white">
                      {student.name}
                    </TableCell>
                    <TableCell className="text-gray-300">
                      Grade {student.gradeLevel}
                    </TableCell>
                    <TableCell className="text-gray-300">
                      {student.parentEmail}
                    </TableCell>
                    {selectedQuarter === "all" || selectedQuarter === "q1" ? (
                      <TableCell>
                        <Badge
                          className={`${getGradeStatusColor(student.q1)} text-white font-medium px-3 py-1`}
                        >
                          {student.q1}
                        </Badge>
                      </TableCell>
                    ) : null}
                    {selectedQuarter === "all" || selectedQuarter === "q2" ? (
                      <TableCell>
                        <Badge
                          className={`${getGradeStatusColor(student.q2)} text-white font-medium px-3 py-1`}
                        >
                          {student.q2}
                        </Badge>
                      </TableCell>
                    ) : null}
                    {selectedQuarter === "all" || selectedQuarter === "q3" ? (
                      <TableCell>
                        <Badge
                          className={`${getGradeStatusColor(student.q3)} text-white font-medium px-3 py-1`}
                        >
                          {student.q3}
                        </Badge>
                      </TableCell>
                    ) : null}
                    {selectedQuarter === "all" || selectedQuarter === "q4" ? (
                      <TableCell>
                        <Badge
                          className={`${getGradeStatusColor(student.q4)} text-white font-medium px-3 py-1`}
                        >
                          {student.q4}
                        </Badge>
                      </TableCell>
                    ) : null}
                    <TableCell>
                      <Badge
                        className={`${getGradeStatusColor(student.average)} text-white font-bold px-3 py-1`}
                      >
                        {student.average.toFixed(1)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          onClick={() => handleSendEmail(student)}
                          size="sm"
                          className="bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:from-purple-600 hover:via-pink-600 hover:to-red-600 text-white"
                        >
                          <Send className="mr-1 h-3 w-3" />
                          Send
                        </Button>
                        {!readOnly && (
                          <Button
                            onClick={() => handleRemoveStudent(student.id)}
                            size="sm"
                            variant="destructive"
                          >
                            <Trash className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>

                  {/* Subject rows */}
                  {student.subjects.map((subject, subjectIndex) => (
                    <TableRow
                      key={`${student.id}-${subject.name}`}
                      className="border-t border-gray-700 bg-gray-800/30"
                    >
                      <TableCell className="pl-8 text-gray-400">
                        {subject.name}
                      </TableCell>
                      <TableCell colSpan={2}></TableCell>
                      {selectedQuarter === "all" || selectedQuarter === "q1" ? (
                        <TableCell>
                          {readOnly ? (
                            <Badge
                              className={`${getGradeStatusColor(subject.q1)} text-white font-medium px-3 py-1`}
                            >
                              {subject.q1}
                            </Badge>
                          ) : (
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              value={subject.q1}
                              onChange={(e) =>
                                handleGradeChange(
                                  student.id,
                                  subjectIndex,
                                  "q1",
                                  parseInt(e.target.value) || 0,
                                )
                              }
                              className="w-16 h-8 bg-gray-700 border-gray-600 text-white text-center"
                            />
                          )}
                        </TableCell>
                      ) : null}
                      {selectedQuarter === "all" || selectedQuarter === "q2" ? (
                        <TableCell>
                          {readOnly ? (
                            <Badge
                              className={`${getGradeStatusColor(subject.q2)} text-white font-medium px-3 py-1`}
                            >
                              {subject.q2}
                            </Badge>
                          ) : (
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              value={subject.q2}
                              onChange={(e) =>
                                handleGradeChange(
                                  student.id,
                                  subjectIndex,
                                  "q2",
                                  parseInt(e.target.value) || 0,
                                )
                              }
                              className="w-16 h-8 bg-gray-700 border-gray-600 text-white text-center"
                            />
                          )}
                        </TableCell>
                      ) : null}
                      {selectedQuarter === "all" || selectedQuarter === "q3" ? (
                        <TableCell>
                          {readOnly ? (
                            <Badge
                              className={`${getGradeStatusColor(subject.q3)} text-white font-medium px-3 py-1`}
                            >
                              {subject.q3}
                            </Badge>
                          ) : (
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              value={subject.q3}
                              onChange={(e) =>
                                handleGradeChange(
                                  student.id,
                                  subjectIndex,
                                  "q3",
                                  parseInt(e.target.value) || 0,
                                )
                              }
                              className="w-16 h-8 bg-gray-700 border-gray-600 text-white text-center"
                            />
                          )}
                        </TableCell>
                      ) : null}
                      {selectedQuarter === "all" || selectedQuarter === "q4" ? (
                        <TableCell>
                          {readOnly ? (
                            <Badge
                              className={`${getGradeStatusColor(subject.q4)} text-white font-medium px-3 py-1`}
                            >
                              {subject.q4}
                            </Badge>
                          ) : (
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              value={subject.q4}
                              onChange={(e) =>
                                handleGradeChange(
                                  student.id,
                                  subjectIndex,
                                  "q4",
                                  parseInt(e.target.value) || 0,
                                )
                              }
                              className="w-16 h-8 bg-gray-700 border-gray-600 text-white text-center"
                            />
                          )}
                        </TableCell>
                      ) : null}
                      <TableCell>
                        <Badge
                          className={`${getGradeStatusColor(subject.average)} text-white font-medium px-3 py-1`}
                        >
                          {subject.average.toFixed(1)}
                        </Badge>
                      </TableCell>
                      <TableCell></TableCell>
                    </TableRow>
                  ))}
                </React.Fragment>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default ExcelStyleTable;
