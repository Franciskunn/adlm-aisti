import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Mail,
  Search,
  Filter,
  ArrowUpDown,
  Send,
  Edit,
  Trash,
  Eye,
} from "lucide-react";
import { useTheme } from "@/components/ThemeProvider";

interface Student {
  id: string;
  name: string;
  parentEmail: string;
  q1: number;
  q2: number;
  q3: number;
  q4: number;
  average: number;
  gradeLevel?: 7 | 8 | 9 | 10;
}

interface StudentTableProps {
  students?: Student[];
  onSendEmail?: (emails: string[]) => void;
  onEdit?: (student: Student) => void;
  onDelete?: (studentId: string) => void;
  onView?: (student: Student) => void;
  allowEdit?: boolean;
  allowDelete?: boolean;
}

const StudentTable = ({
  students = defaultStudents,
  onSendEmail = () => {},
  onEdit = () => {},
  onDelete = () => {},
  onView = () => {},
  allowEdit = false,
  allowDelete = false,
}: StudentTableProps) => {
  const { theme } = useTheme();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof Student;
    direction: "asc" | "desc";
  } | null>(null);

  // Filter students based on search term
  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.parentEmail.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  // Sort students based on sort configuration
  const sortedStudents = React.useMemo(() => {
    let sortableStudents = [...filteredStudents];
    if (sortConfig !== null) {
      sortableStudents.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableStudents;
  }, [filteredStudents, sortConfig]);

  // Handle sort request
  const requestSort = (key: keyof Student) => {
    let direction: "asc" | "desc" = "asc";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "asc"
    ) {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  // Handle select all students
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedStudents(sortedStudents.map((student) => student.id));
    } else {
      setSelectedStudents([]);
    }
  };

  // Handle select individual student
  const handleSelectStudent = (studentId: string, checked: boolean) => {
    if (checked) {
      setSelectedStudents([...selectedStudents, studentId]);
    } else {
      setSelectedStudents(selectedStudents.filter((id) => id !== studentId));
    }
  };

  // Handle send email to selected students' parents
  const handleSendEmail = () => {
    const selectedEmails = sortedStudents
      .filter((student) => selectedStudents.includes(student.id))
      .map((student) => student.parentEmail);

    onSendEmail(selectedEmails);

    // Show success message with animation
    const successMessage = document.createElement("div");
    successMessage.style.position = "fixed";
    successMessage.style.top = "20px";
    successMessage.style.left = "50%";
    successMessage.style.transform = "translateX(-50%)";
    successMessage.style.backgroundColor = "rgba(16, 185, 129, 0.9)";
    successMessage.style.color = "white";
    successMessage.style.padding = "12px 24px";
    successMessage.style.borderRadius = "4px";
    successMessage.style.zIndex = "2000";
    successMessage.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
    successMessage.style.transition = "all 0.3s ease";
    successMessage.style.opacity = "0";
    successMessage.style.transform = "translateX(-50%) translateY(-20px)";
    successMessage.textContent = `Email sent to: ${selectedEmails.join(", ")}\nFrom: depedamba@gmail.com`;

    document.body.appendChild(successMessage);

    setTimeout(() => {
      successMessage.style.opacity = "1";
      successMessage.style.transform = "translateX(-50%) translateY(0)";
    }, 10);

    setTimeout(() => {
      successMessage.style.opacity = "0";
      successMessage.style.transform = "translateX(-50%) translateY(-20px)";
      setTimeout(() => document.body.removeChild(successMessage), 300);
    }, 3000);
  };

  // Get grade status badge color
  const getGradeStatusColor = (grade: number) => {
    if (grade >= 90) return "bg-green-600";
    if (grade >= 75) return "bg-blue-600";
    return "bg-red-600";
  };

  return (
    <Card className="w-full bg-gray-900 border border-indigo-500 rounded-lg overflow-hidden">
      <style jsx>{`
        .row-hover {
          transition: background-color 0.2s ease;
        }
        .row-hover:hover {
          background-color: rgba(79, 70, 229, 0.1) !important;
        }
        .button-hover {
          transition: transform 0.2s ease;
        }
        .button-hover:active {
          transform: scale(0.9);
        }
        .fade-in {
          animation: fadeIn 0.5s ease-in;
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
      <div className="p-4 flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row justify-between gap-4">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search students..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 bg-gray-800 border-gray-700 text-white"
            />
          </div>
          <div className="flex gap-2">
            <Button
              onClick={handleSendEmail}
              disabled={selectedStudents.length === 0}
              className="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 hover:from-blue-600 hover:via-indigo-600 hover:to-purple-600 text-white button-hover"
            >
              <Send className="mr-2 h-4 w-4" />
              Send to Parents
            </Button>
          </div>
        </div>

        <div className="rounded-md border border-indigo-500 overflow-x-auto">
          <Table>
            <TableHeader className="bg-gradient-to-r from-blue-900 to-indigo-900">
              <TableRow>
                <TableHead className="w-12 text-gray-100">
                  <Checkbox
                    checked={
                      selectedStudents.length === sortedStudents.length &&
                      sortedStudents.length > 0
                    }
                    onCheckedChange={(checked) =>
                      handleSelectAll(checked as boolean)
                    }
                  />
                </TableHead>
                <TableHead className="text-gray-100 font-semibold">
                  <div
                    className="flex items-center cursor-pointer"
                    onClick={() => requestSort("name")}
                  >
                    Student Name
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead className="text-gray-100 font-semibold">
                  <div
                    className="flex items-center cursor-pointer"
                    onClick={() => requestSort("parentEmail")}
                  >
                    Parent Email
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead className="text-gray-100 font-semibold">
                  <div
                    className="flex items-center cursor-pointer"
                    onClick={() => requestSort("q1")}
                  >
                    Q1
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead className="text-gray-100 font-semibold">
                  <div
                    className="flex items-center cursor-pointer"
                    onClick={() => requestSort("q2")}
                  >
                    Q2
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead className="text-gray-100 font-semibold">
                  <div
                    className="flex items-center cursor-pointer"
                    onClick={() => requestSort("q3")}
                  >
                    Q3
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead className="text-gray-100 font-semibold">
                  <div
                    className="flex items-center cursor-pointer"
                    onClick={() => requestSort("q4")}
                  >
                    Q4
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead className="text-gray-100 font-semibold">
                  <div
                    className="flex items-center cursor-pointer"
                    onClick={() => requestSort("average")}
                  >
                    Average
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead className="text-gray-100 font-semibold">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedStudents.length > 0 ? (
                sortedStudents.map((student) => (
                  <TableRow
                    key={student.id}
                    className="border-t border-gray-700 hover:bg-gray-800 bg-opacity-50 row-hover fade-in"
                  >
                    <TableCell>
                      <Checkbox
                        checked={selectedStudents.includes(student.id)}
                        onCheckedChange={(checked) =>
                          handleSelectStudent(student.id, checked as boolean)
                        }
                      />
                    </TableCell>
                    <TableCell className="font-medium text-white">
                      {student.name}
                    </TableCell>
                    <TableCell className="text-gray-300">
                      {student.parentEmail}
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={`${getGradeStatusColor(student.q1)} text-white font-medium px-3 py-1`}
                      >
                        {student.q1}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={`${getGradeStatusColor(student.q2)} text-white font-medium px-3 py-1`}
                      >
                        {student.q2}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={`${getGradeStatusColor(student.q3)} text-white font-medium px-3 py-1`}
                      >
                        {student.q3}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={`${getGradeStatusColor(student.q4)} text-white font-medium px-3 py-1`}
                      >
                        {student.q4}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={`${getGradeStatusColor(student.average)} text-white font-bold px-3 py-1`}
                      >
                        {student.average.toFixed(1)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onView(student)}
                          className="h-8 w-8 text-blue-400 hover:text-blue-300 hover:bg-blue-900/20 button-hover"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {allowEdit && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onEdit(student)}
                            className="h-8 w-8 text-amber-400 hover:text-amber-300 hover:bg-amber-900/20 button-hover"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                        {allowDelete && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onDelete(student.id)}
                            className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-900/20 button-hover"
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={10}
                    className={`h-24 text-center ${theme === "dark" ? "text-gray-400" : "text-gray-500"}`}
                  >
                    No students found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </Card>
  );
};

// Default empty array for students
const defaultStudents: Student[] = [];

export default StudentTable;
