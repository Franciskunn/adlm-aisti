import React from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  User,
  Lock,
  Mail,
  Palette,
  CheckCircle2,
  ShieldCheck,
} from "lucide-react";

const ColorSchemeShowcase = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-blue-950 to-indigo-950 p-4">
      <Card className="w-full max-w-4xl bg-blue-950 border-violet-500 border shadow-lg">
        <CardHeader className="bg-gradient-to-r from-blue-900 to-violet-900 text-center">
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-indigo-400 to-violet-400 bg-clip-text text-transparent">
            ALDM Design System
          </CardTitle>
          <CardDescription className="text-gray-300">
            Color scheme and UI components showcase
          </CardDescription>
        </CardHeader>

        <CardContent className="pt-6">
          <Tabs defaultValue="colors" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-blue-900">
              <TabsTrigger
                value="colors"
                className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
              >
                <Palette className="mr-2 h-4 w-4" />
                Colors
              </TabsTrigger>
              <TabsTrigger
                value="components"
                className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
              >
                <CheckCircle2 className="mr-2 h-4 w-4" />
                Components
              </TabsTrigger>
              <TabsTrigger
                value="forms"
                className="data-[state=active]:bg-gradient-to-r from-blue-600 to-violet-600"
              >
                <ShieldCheck className="mr-2 h-4 w-4" />
                Forms
              </TabsTrigger>
            </TabsList>

            <TabsContent value="colors" className="mt-6 space-y-6">
              <div>
                <h3 className="text-xl font-bold text-white mb-4">
                  Primary Colors
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-gradient-to-r from-blue-500 via-indigo-500 to-violet-500"></div>
                    <span className="text-sm text-gray-300 mt-2">
                      Primary Gradient
                    </span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-gradient-to-r from-blue-600 to-violet-600"></div>
                    <span className="text-sm text-gray-300 mt-2">
                      Accent Gradient
                    </span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-gradient-to-r from-blue-800 to-violet-700"></div>
                    <span className="text-sm text-gray-300 mt-2">
                      Header Gradient
                    </span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-gradient-to-r from-blue-500 via-indigo-500 to-violet-500"></div>
                    <span className="text-sm text-gray-300 mt-2">
                      Rainbow Gradient
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-white mb-4">
                  Background Colors
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-blue-950 border border-blue-800"></div>
                    <span className="text-sm text-gray-300 mt-2">
                      Background
                    </span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-blue-900 border border-blue-800"></div>
                    <span className="text-sm text-gray-300 mt-2">
                      Card Background
                    </span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-indigo-950 border border-blue-800"></div>
                    <span className="text-sm text-gray-300 mt-2">
                      Dark Background
                    </span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-black border border-blue-800"></div>
                    <span className="text-sm text-gray-300 mt-2">Black</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-white mb-4">
                  Text Colors
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-blue-900 flex items-center justify-center">
                      <span className="text-white">Aa</span>
                    </div>
                    <span className="text-sm text-gray-300 mt-2">White</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-blue-900 flex items-center justify-center">
                      <span className="text-gray-300">Aa</span>
                    </div>
                    <span className="text-sm text-gray-300 mt-2">Gray 300</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-blue-900 flex items-center justify-center">
                      <span className="text-gray-400">Aa</span>
                    </div>
                    <span className="text-sm text-gray-300 mt-2">Gray 400</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-20 h-20 rounded-md bg-blue-900 flex items-center justify-center">
                      <span className="bg-gradient-to-r from-blue-400 via-indigo-400 to-violet-400 bg-clip-text text-transparent font-bold">
                        Aa
                      </span>
                    </div>
                    <span className="text-sm text-gray-300 mt-2">
                      Gradient Text
                    </span>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="components" className="mt-6 space-y-6">
              <div>
                <h3 className="text-xl font-bold text-white mb-4">Buttons</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button className="bg-gradient-to-r from-blue-500 via-indigo-500 to-violet-500 hover:from-blue-600 hover:via-indigo-600 hover:to-violet-600 text-white">
                    Primary Button
                  </Button>
                  <Button className="bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white">
                    Accent Button
                  </Button>
                  <Button className="bg-gradient-to-r from-blue-500 via-indigo-500 to-violet-500 hover:opacity-90 text-white">
                    Rainbow Button
                  </Button>
                  <Button
                    variant="outline"
                    className="border-indigo-500 text-indigo-400 hover:bg-indigo-950 hover:text-indigo-300"
                  >
                    Outline Button
                  </Button>
                  <Button
                    variant="ghost"
                    className="text-gray-300 hover:bg-blue-900 hover:text-white"
                  >
                    Ghost Button
                  </Button>
                  <Button
                    variant="link"
                    className="text-indigo-400 hover:text-indigo-300"
                  >
                    Link Button
                  </Button>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-white mb-4">Cards</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="bg-blue-950 border-violet-500 border">
                    <CardHeader className="bg-gradient-to-r from-blue-900 to-violet-900">
                      <CardTitle>Card Title</CardTitle>
                      <CardDescription className="text-gray-300">
                        Card description here
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <p className="text-gray-300">
                        This is the content of the card.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-blue-950 border-blue-500 border">
                    <CardHeader className="bg-gradient-to-r from-blue-800 to-violet-800">
                      <CardTitle>Accent Card</CardTitle>
                      <CardDescription className="text-gray-300">
                        With blue accent
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <p className="text-gray-300">
                        This is the content of the card.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="forms" className="mt-6">
              <div className="space-y-6">
                <div className="bg-blue-900 p-6 rounded-lg border border-blue-700">
                  <h3 className="text-xl font-bold text-white mb-4">
                    Form Elements
                  </h3>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="username" className="text-gray-300">
                        Username
                      </Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                        <Input
                          id="username"
                          placeholder="Enter your username"
                          className="pl-10 bg-blue-900 border-blue-700 text-white"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-gray-300">
                        Email
                      </Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                        <Input
                          id="email"
                          type="email"
                          placeholder="Enter your email"
                          className="pl-10 bg-blue-900 border-blue-700 text-white"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-gray-300">
                        Password
                      </Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                        <Input
                          id="password"
                          type="password"
                          placeholder="Enter your password"
                          className="pl-10 bg-blue-900 border-blue-700 text-white"
                        />
                      </div>
                    </div>

                    <Button className="w-full bg-gradient-to-r from-blue-500 via-indigo-500 to-violet-500 hover:from-blue-600 hover:via-indigo-600 hover:to-violet-600 text-white mt-2">
                      Submit Form
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default ColorSchemeShowcase;
