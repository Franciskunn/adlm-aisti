import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Download,
  Send,
  FileSpreadsheet,
  Edit,
  Trash,
} from "lucide-react";

interface Student {
  id: string;
  name: string;
  parentEmail: string;
  q1: number;
  q2: number;
  q3: number;
  q4: number;
  average: number;
  gradeLevel: 7 | 8 | 9 | 10;
}

const GradeLevelDashboard = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGradeLevel, setSelectedGradeLevel] = useState<7 | 8 | 9 | 10>(
    7,
  );
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);

  // Load students from localStorage
  useEffect(() => {
    const storedStudents = localStorage.getItem("students");
    if (storedStudents) {
      setStudents(JSON.parse(storedStudents));
    } else {
      // Initialize with empty array if none exists
      setStudents([]);
      localStorage.setItem("students", JSON.stringify([]));
    }
  }, []);

  // Filter students based on search term and grade level
  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.parentEmail.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGradeLevel = student.gradeLevel === selectedGradeLevel;

    return matchesSearch && matchesGradeLevel;
  });

  // Handle select all students
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedStudents(filteredStudents.map((student) => student.id));
    } else {
      setSelectedStudents([]);
    }
  };

  // Handle select individual student
  const handleSelectStudent = (studentId: string, checked: boolean) => {
    if (checked) {
      setSelectedStudents([...selectedStudents, studentId]);
    } else {
      setSelectedStudents(selectedStudents.filter((id) => id !== studentId));
    }
  };

  // Handle send email to selected students' parents
  const handleSendEmail = () => {
    const selectedEmails = filteredStudents
      .filter((student) => selectedStudents.includes(student.id))
      .map((student) => student.parentEmail);

    alert(`Email would be sent to: ${selectedEmails.join(", ")}`);
    // In a real implementation, this would integrate with EmailJS or similar
  };

  // Handle export to Excel
  const handleExportToExcel = () => {
    alert("Exporting data to Excel...");
    // In a real implementation, this would generate and download an Excel file
  };

  // Get grade status color
  const getGradeStatusColor = (grade: number) => {
    if (grade >= 90) return "bg-green-600";
    if (grade >= 75) return "bg-blue-600";
    return "bg-red-600";
  };

  // Calculate grade level statistics
  const calculateStats = () => {
    const gradeStudents = students.filter(
      (student) => student.gradeLevel === selectedGradeLevel,
    );

    if (gradeStudents.length === 0)
      return { count: 0, avgScore: 0, passing: 0, failing: 0 };

    const totalAverage = gradeStudents.reduce(
      (sum, student) => sum + student.average,
      0,
    );
    const avgScore = totalAverage / gradeStudents.length;
    const passing = gradeStudents.filter(
      (student) => student.average >= 75,
    ).length;
    const failing = gradeStudents.length - passing;

    return {
      count: gradeStudents.length,
      avgScore: avgScore.toFixed(1),
      passing,
      failing,
    };
  };

  const stats = calculateStats();

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-950 text-white p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 bg-clip-text text-transparent">
            Grade Level Dashboard
          </h1>
          <p className="text-gray-400 mt-1">
            Comprehensive view of student performance by grade level
          </p>
        </header>

        <Tabs
          defaultValue="7"
          value={selectedGradeLevel.toString()}
          onValueChange={(value) =>
            setSelectedGradeLevel(parseInt(value) as 7 | 8 | 9 | 10)
          }
          className="w-full"
        >
          <TabsList className="grid grid-cols-4 mb-6 bg-gradient-to-r from-blue-900 to-indigo-900 p-1 rounded-md">
            <TabsTrigger
              value="7"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white"
            >
              Grade 7
            </TabsTrigger>
            <TabsTrigger
              value="8"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white"
            >
              Grade 8
            </TabsTrigger>
            <TabsTrigger
              value="9"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white"
            >
              Grade 9
            </TabsTrigger>
            <TabsTrigger
              value="10"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white"
            >
              Grade 10
            </TabsTrigger>
          </TabsList>

          {[7, 8, 9, 10].map((grade) => (
            <TabsContent
              key={grade}
              value={grade.toString()}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border-red-500 shadow-lg">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium text-gray-100">
                      Total Students
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-white">
                      {stats.count}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border-red-500 shadow-lg">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium text-gray-100">
                      Average Score
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-white">
                      {stats.avgScore}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border-red-500 shadow-lg">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium text-gray-100">
                      Passing
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-500">
                      {stats.passing}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border-red-500 shadow-lg">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium text-gray-100">
                      Failing
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-red-500">
                      {stats.failing}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border-red-500 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-white">
                    Grade {grade} Student Records
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Spreadsheet view of all student grades and performance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row justify-between gap-4 mb-4">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search students by name or email..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 bg-gray-700 border-gray-600 text-white w-full"
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={handleExportToExcel}
                        variant="outline"
                        className="border-green-500 text-green-400 hover:bg-green-950 hover:text-green-300"
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Export to Excel
                      </Button>

                      <Button
                        onClick={handleSendEmail}
                        disabled={selectedStudents.length === 0}
                        className="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 hover:from-blue-600 hover:via-indigo-600 hover:to-purple-600 text-white font-medium"
                      >
                        <Send className="mr-2 h-4 w-4" />
                        Send Reports
                      </Button>
                    </div>
                  </div>

                  <div className="rounded-md border border-indigo-500 overflow-x-auto">
                    <Table>
                      <TableHeader className="bg-gradient-to-r from-blue-900 to-indigo-900">
                        <TableRow>
                          <TableHead className="w-12 text-gray-100">
                            <input
                              type="checkbox"
                              checked={
                                selectedStudents.length ===
                                  filteredStudents.length &&
                                filteredStudents.length > 0
                              }
                              onChange={(e) =>
                                handleSelectAll(e.target.checked)
                              }
                              className="rounded bg-gray-700 border-gray-600"
                            />
                          </TableHead>
                          <TableHead className="text-gray-100 font-semibold">
                            Student Name
                          </TableHead>
                          <TableHead className="text-gray-100 font-semibold">
                            Parent Email
                          </TableHead>
                          <TableHead className="text-gray-100 font-semibold">
                            Q1
                          </TableHead>
                          <TableHead className="text-gray-100 font-semibold">
                            Q2
                          </TableHead>
                          <TableHead className="text-gray-100 font-semibold">
                            Q3
                          </TableHead>
                          <TableHead className="text-gray-100 font-semibold">
                            Q4
                          </TableHead>
                          <TableHead className="text-gray-100 font-semibold">
                            Average
                          </TableHead>
                          <TableHead className="text-gray-100 font-semibold">
                            Status
                          </TableHead>
                          <TableHead className="text-gray-100 font-semibold">
                            Actions
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredStudents.length > 0 ? (
                          filteredStudents.map((student) => (
                            <TableRow
                              key={student.id}
                              className="border-t border-gray-700 hover:bg-gray-800"
                            >
                              <TableCell>
                                <input
                                  type="checkbox"
                                  checked={selectedStudents.includes(
                                    student.id,
                                  )}
                                  onChange={(e) =>
                                    handleSelectStudent(
                                      student.id,
                                      e.target.checked,
                                    )
                                  }
                                  className="rounded bg-gray-700 border-gray-600"
                                />
                              </TableCell>
                              <TableCell className="font-medium text-white">
                                {student.name}
                              </TableCell>
                              <TableCell className="text-gray-300">
                                {student.parentEmail}
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={`${getGradeStatusColor(student.q1)} text-white font-medium px-3 py-1`}
                                >
                                  {student.q1}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={`${getGradeStatusColor(student.q2)} text-white font-medium px-3 py-1`}
                                >
                                  {student.q2}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={`${getGradeStatusColor(student.q3)} text-white font-medium px-3 py-1`}
                                >
                                  {student.q3}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={`${getGradeStatusColor(student.q4)} text-white font-medium px-3 py-1`}
                                >
                                  {student.q4}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={`${getGradeStatusColor(student.average)} text-white font-bold px-3 py-1`}
                                >
                                  {student.average.toFixed(1)}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  className={
                                    student.average >= 75
                                      ? "border-green-500 text-green-400"
                                      : "border-red-500 text-red-400"
                                  }
                                >
                                  {student.average >= 75 ? "Passed" : "Failed"}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex space-x-2">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => {
                                      const updatedName = prompt(
                                        "Enter updated student name:",
                                        student.name,
                                      );
                                      const updatedEmail = prompt(
                                        "Enter updated parent email:",
                                        student.parentEmail,
                                      );
                                      const updatedQ1 = parseInt(
                                        prompt(
                                          "Enter Q1 grade:",
                                          student.q1.toString(),
                                        ) || "0",
                                      );
                                      const updatedQ2 = parseInt(
                                        prompt(
                                          "Enter Q2 grade:",
                                          student.q2.toString(),
                                        ) || "0",
                                      );
                                      const updatedQ3 = parseInt(
                                        prompt(
                                          "Enter Q3 grade:",
                                          student.q3.toString(),
                                        ) || "0",
                                      );
                                      const updatedQ4 = parseInt(
                                        prompt(
                                          "Enter Q4 grade:",
                                          student.q4.toString(),
                                        ) || "0",
                                      );

                                      if (updatedName && updatedEmail) {
                                        const updatedAverage =
                                          (updatedQ1 +
                                            updatedQ2 +
                                            updatedQ3 +
                                            updatedQ4) /
                                          4;

                                        const updatedStudents = students.map(
                                          (s) => {
                                            if (s.id === student.id) {
                                              return {
                                                ...s,
                                                name: updatedName,
                                                parentEmail: updatedEmail,
                                                q1: updatedQ1,
                                                q2: updatedQ2,
                                                q3: updatedQ3,
                                                q4: updatedQ4,
                                                average: updatedAverage,
                                              };
                                            }
                                            return s;
                                          },
                                        );

                                        setStudents(updatedStudents);
                                        localStorage.setItem(
                                          "students",
                                          JSON.stringify(updatedStudents),
                                        );
                                        alert(
                                          `Student ${updatedName} updated successfully`,
                                        );
                                      }
                                    }}
                                    className="h-8 w-8 text-amber-400 hover:text-amber-300 hover:bg-amber-900/20"
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => {
                                      if (
                                        window.confirm(
                                          "Are you sure you want to delete this student?",
                                        )
                                      ) {
                                        const updatedStudents = students.filter(
                                          (s) => s.id !== student.id,
                                        );
                                        localStorage.setItem(
                                          "students",
                                          JSON.stringify(updatedStudents),
                                        );
                                        alert(
                                          `Student ${student.name} deleted successfully`,
                                        );
                                      }
                                    }}
                                    className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-900/20"
                                  >
                                    <Trash className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell
                              colSpan={10}
                              className="h-24 text-center text-gray-400"
                            >
                              No students found for Grade {grade}.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
};

// Helper function to generate empty student array
function generateSampleStudents(): Student[] {
  return [];
}

export default GradeLevelDashboard;
